"""
Tally Voice Bridge for Verma Jewellers.

Runs on the shop's Windows PC next to TallyPrime. The ElevenLabs voice agent
calls this over HTTPS (through a Cloudflare tunnel); the bridge talks to
TallyPrime's XML port (default http://localhost:9000) and creates Receipt
vouchers.

Standard library only. Python 3.9+.

Endpoints (all need header  X-Bridge-Token: <token from config.json>):
  GET  /health                      -> is Tally reachable, which company
  POST /find_party   {name}         -> closest matching party ledgers
  POST /create_party {name}         -> create a ledger under Sundry Debtors
  POST /create_receipt {...}        -> post a Receipt voucher
"""

import datetime as dt
import difflib
import html
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(HERE, "config.json")
LOG_PATH = os.path.join(HERE, "receipts_log.jsonl")
APP_LOG = os.path.join(HERE, "app.log")


def applog(src, level, msg):
    """Problems only (UI errors, failed calls, Tally errors) -> app.log, newest at the bottom."""
    try:
        if os.path.exists(APP_LOG) and os.path.getsize(APP_LOG) > 2_000_000:
            os.replace(APP_LOG, APP_LOG + ".old")
        with open(APP_LOG, "a", encoding="utf-8") as f:
            f.write(f"{dt.datetime.now():%Y-%m-%d %H:%M:%S} [{src} {level}] {msg}\n")
    except Exception:
        pass

DEFAULT_CONFIG = {
    "port": 8765,
    "token": "CHANGE_ME",
    "tally_url": "http://localhost:9000",
    "company": "",                 # exact company name in Tally; "" = currently open company
    "party_group": "Sundry Debtors",
    "voucher_type": "Receipt",
    "mode_ledgers": {"cash": "Cash", "upi": "", "bank": ""},
    "ledger_cache_seconds": 300,
    "agent_id": "agent_5001m6p2jrrne1yrpw89wyytq8ap",
    "billwise": False,            # True = add "Agst Ref <bill no>" allocation on receipts
    "lookup_years": 2,            # how many financial years back to search bills
    "sales_voucher_type": "Sales New",
    "bill_items_in_tally": True,   # bills as item invoices: each item is a stock line (weight, rate) in Particulars
    "stock_unit": "gm",
    "stock_godown": "Main Location",
    "sales_ledger": "Sales@3%",
    "cloud_url": "https://vgenowecsrxxaqtsgfmy.supabase.co/functions/v1/tv-api",
    "admin": False,               # True on our own PCs: shows API-key fields and cost line
}


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg.update(json.load(f))
    return cfg


CFG = load_config()
_lock = threading.Lock()
_ledger_cache = {"at": 0.0, "items": []}


# ---------------------------------------------------------------- Tally I/O

def esc(s):
    return html.escape(str(s), quote=True)


def clean_xml(text):
    # Tally sometimes returns control-character entities that break XML parsers.
    text = re.sub(r"&#(?:[0-8]|1[124-9]|2\d|3[01]);", "", text)
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", text)


def tally_post(xml_body, timeout=20):
    req = urllib.request.Request(
        CFG["tally_url"],
        data=xml_body.encode("utf-8"),
        headers={"Content-Type": "text/xml; charset=utf-8"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
    for enc in ("utf-8", "utf-16", "latin-1"):
        try:
            return clean_xml(raw.decode(enc))
        except UnicodeDecodeError:
            continue
    return clean_xml(raw.decode("utf-8", "ignore"))


def company_vars():
    c = CFG.get("company") or ""
    return f"<SVCURRENTCOMPANY>{esc(c)}</SVCURRENTCOMPANY>" if c else ""


def fetch_ledgers(force=False):
    now = time.time()
    if not force and now - _ledger_cache["at"] < CFG["ledger_cache_seconds"] and _ledger_cache["items"]:
        return _ledger_cache["items"]
    body = f"""<ENVELOPE>
<HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>VoiceBridgeLedgers</ID></HEADER>
<BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>{company_vars()}</STATICVARIABLES>
<TDL><TDLMESSAGE><COLLECTION NAME="VoiceBridgeLedgers" ISMODIFY="No"><TYPE>Ledger</TYPE><FETCH>Name,Parent</FETCH></COLLECTION></TDLMESSAGE></TDL>
</DESC></BODY></ENVELOPE>"""
    text = tally_post(body)
    items = []
    try:
        root = ET.fromstring(text)
        for led in root.iter("LEDGER"):
            name = led.get("NAME") or (led.findtext("NAME") or "")
            parent = led.findtext("PARENT") or ""
            if name:
                items.append({"name": html.unescape(name), "parent": html.unescape(parent)})
    except ET.ParseError:
        for m in re.finditer(r'<LEDGER NAME="([^"]+)"[^>]*>.*?<PARENT[^>]*>([^<]*)</PARENT>', text, re.S):
            items.append({"name": html.unescape(m.group(1)), "parent": html.unescape(m.group(2))})
    _ledger_cache.update(at=now, items=items)
    return items


def parse_import_response(text):
    def num(tag):
        m = re.search(rf"<{tag}>\s*(-?\d+)\s*</{tag}>", text)
        return int(m.group(1)) if m else 0
    errors = re.findall(r"<LINEERROR>(.*?)</LINEERROR>", text, re.S)
    return {
        "created": num("CREATED"),
        "altered": num("ALTERED"),
        "errors": num("ERRORS"),
        "exceptions": num("EXCEPTIONS"),
        "last_vch_id": num("LASTVCHID"),
        "line_errors": [html.unescape(e.strip()) for e in errors],
    }


def import_xml(report, inner):
    body = f"""<ENVELOPE>
<HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER>
<BODY><IMPORTDATA>
<REQUESTDESC><REPORTNAME>{report}</REPORTNAME><STATICVARIABLES>{company_vars()}</STATICVARIABLES></REQUESTDESC>
<REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF">{inner}</TALLYMESSAGE></REQUESTDATA>
</IMPORTDATA></BODY></ENVELOPE>"""
    return parse_import_response(tally_post(body))


# ---------------------------------------------------------------- logic

HONORIFICS = {"ji", "shri", "shree", "smt", "mr", "mrs", "bhai", "bai", "sahab", "saheb", "seth", "bhaiya", "didi"}


def tokens(s):
    t = re.findall(r"[a-z0-9]+", s.lower())
    core = [x for x in t if x not in HONORIFICS]
    return core or t


def norm(s):
    return "".join(tokens(s))


def _ratio(a, b):
    return difflib.SequenceMatcher(None, a, b).ratio()


def score_name(query, ledger):
    q, l = tokens(query), tokens(ledger)
    if not q or not l:
        return 0.0
    # each spoken word must match some word of the ledger name
    tok = sum(max(_ratio(a, b) for b in l) for a in q) / len(q)
    full = _ratio(" ".join(q), " ".join(l))
    s = 0.75 * tok + 0.25 * full
    if norm(query) == norm(ledger):
        s = 1.0
    return round(s, 3)


def find_party(name, limit=5):
    ledgers = fetch_ledgers()
    group = CFG["party_group"].lower()
    parties = [l for l in ledgers if l["parent"].lower() == group] or ledgers
    scored = sorted(((score_name(name, l["name"]), l["name"]) for l in parties), reverse=True)
    top = [{"ledger": n, "score": s} for s, n in scored[:limit] if s >= 0.6]
    q_full = name.lower().strip()
    exact = next((t for t in top if t["ledger"].lower() == q_full or t["score"] >= 1.0), None)
    clear = bool(top) and top[0]["score"] >= 0.92 and (len(top) == 1 or top[0]["score"] - top[1]["score"] >= 0.08)
    qt = set(tokens(name))
    full_hits = [l["name"] for l in parties if qt and qt <= set(tokens(l["name"]))]
    if len(full_hits) == 1 and not exact:
        clear, top = True, [{"ledger": full_hits[0], "score": max(0.95, score_name(name, full_hits[0]))}] + [t for t in top if t["ledger"] != full_hits[0]][:limit - 1]
    return {
        "query": name,
        "exact_match": exact["ledger"] if exact else None,
        "best_match": top[0]["ledger"] if clear else None,
        "candidates": top,
        "same_word_matches": len(full_hits),
        "note": "Several close matches: ask which one (read the extra words like place names)." if top and not clear and not exact else "",
    }


def _parent_of(name):
    for l in fetch_ledgers():
        if l["name"].lower() == name.lower():
            return l["name"], l["parent"]
    return None, None


def _amt(x):
    try:
        return float(str(x or "0").replace(",", "").strip() or 0)
    except ValueError:
        return 0.0


def _tdate(d):
    return d.strftime("%d-%b-%Y")


def sv_dates(frm, to):
    # This Tally build only honours the period when the variables are typed as Date.
    return f'<SVFROMDATE TYPE="Date">{_tdate(frm)}</SVFROMDATE><SVTODATE TYPE="Date">{_tdate(to)}</SVTODATE>'


def _fy_range():
    today = dt.date.today()
    start_year = today.year if today.month >= 4 else today.year - 1
    start = dt.date(start_year - (int(CFG.get("lookup_years", 2)) - 1), 4, 1)
    return start, today


_contact_cache = {"at": 0.0, "items": []}


def fetch_contacts(force=False):
    """Every ledger that has a mobile/phone saved in Tally: name, mobile, address."""
    now = time.time()
    if not force and now - _contact_cache["at"] < CFG["ledger_cache_seconds"] and _contact_cache["at"]:
        return _contact_cache["items"]
    body = f"""<ENVELOPE>
<HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>VoiceBridgeContacts</ID></HEADER>
<BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>{company_vars()}</STATICVARIABLES>
<TDL><TDLMESSAGE><COLLECTION NAME="VoiceBridgeContacts" ISMODIFY="No"><TYPE>Ledger</TYPE>
<FETCH>Name,Parent,LedgerMobile,LedgerPhone,Address</FETCH></COLLECTION></TDLMESSAGE></TDL>
</DESC></BODY></ENVELOPE>"""
    items = []
    try:
        text = tally_post(body, timeout=40)
        for m in re.finditer(r'<LEDGER NAME="([^"]+)"[^>]*>(.*?)</LEDGER>', text, re.S):
            inner = m.group(2)
            mob = " ".join(re.findall(r"<(?:LEDGERMOBILE|LEDGERPHONE)[^>]*>([^<]*)</", inner))
            if not re.search(r"\d{10}", re.sub(r"\D", "", mob)):
                continue
            addr = [html.unescape(a).strip() for a in re.findall(r"<ADDRESS[^>]*>([^<]+)</ADDRESS>", inner) if a.strip()]
            items.append({"ledger": html.unescape(m.group(1)), "mobile": mob, "location": ", ".join(addr)})
        _contact_cache.update(at=now, items=items)
    except Exception as e:
        applog("CONTACTS", "FAIL", str(e))
        return _contact_cache["items"]
    return items


def by_mobile(mobile):
    d = re.sub(r"\D", "", str(mobile or ""))[-10:]
    if len(d) != 10:
        return {"ok": False, "error": "need 10 digits", "matches": []}
    found = {}
    for c in fetch_contacts():
        if d in re.sub(r"\D", "", c["mobile"]):
            found[c["ledger"]] = {"ledger": c["ledger"], "location": c["location"], "source": "tally"}
    # numbers saved with bills from this app (also covers ledgers Tally hasn't refreshed yet)
    try:
        if os.path.exists(LOG_PATH):
            with open(LOG_PATH, encoding="utf-8") as fh:
                for line in fh:
                    try:
                        r = json.loads(line)
                    except ValueError:
                        continue
                    c = r.get("contact") or {}
                    if r.get("ok") and r.get("party_ledger") and re.sub(r"\D", "", c.get("mobile", ""))[-10:] == d:
                        found.setdefault(r["party_ledger"], {"ledger": r["party_ledger"], "location": c.get("location", ""), "source": "app"})
    except OSError:
        pass
    known = {l["name"] for l in fetch_ledgers()}
    matches = [m for m in found.values() if m["ledger"] in known]
    for m in matches:
        if not m["location"]:
            m["location"] = ", ".join(party_contact(m["ledger"]).get("address") or [])
    return {"ok": True, "mobile": d, "matches": matches}


def party_info(ledger):
    body = f"""<ENVELOPE>
<HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Object</TYPE><SUBTYPE>Ledger</SUBTYPE><ID TYPE="Name">{esc(ledger)}</ID></HEADER>
<BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>{company_vars()}</STATICVARIABLES>
<FETCHLIST><FETCH>Name</FETCH><FETCH>Parent</FETCH><FETCH>ClosingBalance</FETCH></FETCHLIST>
</DESC></BODY></ENVELOPE>"""
    text = tally_post(body)
    m = re.search(r"<CLOSINGBALANCE[^>]*>([^<]*)</CLOSINGBALANCE>", text)
    parent = re.search(r"<PARENT[^>]*>([^<]*)</PARENT>", text)
    if not m and not parent:
        return {"ok": False, "error": "ledger_not_found", "ledger": ledger}
    bal = _amt(m.group(1) if m else 0)
    pc = party_contact(ledger)
    return {"ok": True, "ledger": ledger, "group": html.unescape(parent.group(1)) if parent else "",
            "mobile": pc.get("mobile", ""), "location": ", ".join(pc.get("address") or []),
            "balance": abs(bal), "balance_side": "Dr" if bal < 0 else ("Cr" if bal > 0 else ""),
            "owes_us": abs(bal) if bal < 0 else 0.0}


VCH_FETCH = ("Date,VoucherNumber,Reference,PartyLedgerName,VoucherTypeName,Narration,MasterId,Guid,IsCancelled,"
             "AllLedgerEntries.LedgerName,AllLedgerEntries.Amount,AllLedgerEntries.BillAllocations.Name,AllLedgerEntries.BillAllocations.BillType,"
             "LedgerEntries.LedgerName,LedgerEntries.Amount,LedgerEntries.BillAllocations.Name,LedgerEntries.BillAllocations.BillType")


def parse_voucher(v, party=None):
    party = party or html.unescape(v.findtext("PARTYLEDGERNAME") or "")
    amt, bill_ref, bill_type, contra, dr = 0.0, "", "", "", None
    for e in list(v.iter("ALLLEDGERENTRIES.LIST")) + list(v.iter("LEDGERENTRIES.LIST")):
        ln = html.unescape(e.findtext("LEDGERNAME") or "")
        if ln == party and not amt:
            raw = _amt(e.findtext("AMOUNT"))
            amt, dr = abs(raw), raw < 0
            for b in e.iter("BILLALLOCATIONS.LIST"):
                bt = (b.findtext("BILLTYPE") or "").strip()
                nm = (b.findtext("NAME") or "").strip()
                if bt or nm:
                    bill_ref, bill_type = html.unescape(nm), bt
                    break
        elif ln and ln != party and not contra:
            contra = ln
    d = v.findtext("DATE") or ""
    return {
        "type": html.unescape(v.findtext("VOUCHERTYPENAME") or v.get("VCHTYPE") or ""),
        "number": (v.findtext("VOUCHERNUMBER") or "").strip(),
        "reference": (v.findtext("REFERENCE") or "").strip(),
        "date": f"{d[6:8]}-{d[4:6]}-{d[0:4]}" if len(d) == 8 else d,
        "date_iso": f"{d[0:4]}-{d[4:6]}-{d[6:8]}" if len(d) == 8 else "",
        "party": party, "amount": amt, "contra": contra, "dr": dr, "bill_ref": bill_ref, "bill_type": bill_type,
        "narration": html.unescape(v.findtext("NARRATION") or "")[:200],
        "narration_full": html.unescape(v.findtext("NARRATION") or ""),
        "master_id": (v.findtext("MASTERID") or "").strip(),
        "guid": (v.findtext("GUID") or "").strip(),
        "cancelled": (v.findtext("ISCANCELLED") or "").strip().lower() == "yes",
    }


def query_vouchers(formula, frm, to, timeout=60, extra="", party=None):
    body = f"""<ENVELOPE>
<HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>VBQ</ID></HEADER>
<BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>{company_vars()}{sv_dates(frm, to)}</STATICVARIABLES>
<TDL><TDLMESSAGE>
<COLLECTION NAME="VBQ" ISMODIFY="No"><TYPE>Voucher</TYPE><FETCH>{VCH_FETCH}</FETCH><FILTER>VBQF</FILTER></COLLECTION>
<SYSTEM TYPE="Formulae" NAME="VBQF">{formula}</SYSTEM>{extra}
</TDLMESSAGE></TDL></DESC></BODY></ENVELOPE>"""
    root = ET.fromstring(tally_post(body, timeout=timeout))
    out = [parse_voucher(v, party) for v in root.iter("VOUCHER")]
    return [v for v in out if v["master_id"] or v["type"] or v["number"]]   # Tally sometimes adds an empty element


def find_vouchers(number):
    number = str(number or "").strip()
    if not number:
        return {"ok": False, "error": "empty"}
    q = number.replace('"', "")
    frm, to = _fy_range()
    try:
        out = query_vouchers(f'$VoucherNumber = "{q}" OR $Reference = "{q}"', frm, to + dt.timedelta(days=366))
    except ET.ParseError:
        return {"ok": False, "error": "could not read Tally reply"}
    out = [v for v in out if not v["cancelled"]]
    return {"ok": True, "query": number, "count": len(out), "vouchers": out[:10]}


def get_voucher(master_id, date_iso=""):
    mid = int(str(master_id).strip())
    ranges = []
    if date_iso:
        d = parse_date(date_iso)
        ranges.append((d, d))
    frm, to = _fy_range()
    ranges.append((frm, to + dt.timedelta(days=366)))
    for a, b in ranges:
        vs = query_vouchers(f"$MasterId = {mid}", a, b)
        if vs:
            return vs[0]
    return None


def debug_vouchers(number, days=3):
    to = dt.date.today(); frm = to - dt.timedelta(days=days)
    q = str(number).replace('"', "")
    flt = f'<FILTER>VBNumF</FILTER></COLLECTION><SYSTEM TYPE="Formulae" NAME="VBNumF">$VoucherNumber = "{q}"</SYSTEM>' if q else "</COLLECTION>"
    body = f"""<ENVELOPE>
<HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>VBDbg</ID></HEADER>
<BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>{company_vars()}
{sv_dates(frm, to)}</STATICVARIABLES>
<TDL><TDLMESSAGE>
<COLLECTION NAME="VBDbg" ISMODIFY="No"><TYPE>Voucher</TYPE>
<FETCH>Date,VoucherNumber,Reference,PartyLedgerName,VoucherTypeName,AllLedgerEntries.LedgerName,AllLedgerEntries.Amount</FETCH>
{flt}
</TDLMESSAGE></TDL></DESC></BODY></ENVELOPE>"""
    text = tally_post(body, timeout=60)
    return {"len": len(text), "head": text[:3500]}


def vch_stats(days=60, sample_type="", n=6):
    to = dt.date.today(); frm = to - dt.timedelta(days=int(days))
    body = f"""<ENVELOPE>
<HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>VBStats</ID></HEADER>
<BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>{company_vars()}
{sv_dates(frm, to)}</STATICVARIABLES>
<TDL><TDLMESSAGE>
<COLLECTION NAME="VBStats" ISMODIFY="No"><TYPE>Voucher</TYPE>
<FETCH>Date,VoucherNumber,Reference,PartyLedgerName,VoucherTypeName,Narration,AllLedgerEntries.LedgerName,AllLedgerEntries.Amount,AllLedgerEntries.BillAllocations.Name,AllLedgerEntries.BillAllocations.BillType,LedgerEntries.LedgerName,LedgerEntries.Amount</FETCH>
</COLLECTION>
</TDLMESSAGE></TDL></DESC></BODY></ENVELOPE>"""
    text = tally_post(body, timeout=120)
    root = ET.fromstring(text)
    counts, samples = {}, []
    for v in root.iter("VOUCHER"):
        t = v.findtext("VOUCHERTYPENAME") or v.get("VCHTYPE") or ""
        counts[t] = counts.get(t, 0) + 1
        if sample_type and t.lower() == sample_type.lower() and len(samples) < n:
            ents = []
            for e in list(v.iter("ALLLEDGERENTRIES.LIST")) + list(v.iter("LEDGERENTRIES.LIST")):
                bills = [(b.findtext("NAME"), b.findtext("BILLTYPE")) for b in e.iter("BILLALLOCATIONS.LIST")]
                ents.append({"ledger": e.findtext("LEDGERNAME"), "amount": e.findtext("AMOUNT"), "bills": bills})
            samples.append({"date": v.findtext("DATE"), "number": v.findtext("VOUCHERNUMBER"), "ref": v.findtext("REFERENCE"),
                            "party": v.findtext("PARTYLEDGERNAME"), "narration": v.findtext("NARRATION"), "entries": ents})
    return {"from": str(frm), "to": str(to), "counts": counts, "samples": samples}


_next_cache = {}


def next_receipt_no(force=False):
    return _next_number(CFG["voucher_type"], "receipt", force)


def next_bill_no(force=False):
    return _next_number(CFG["sales_voucher_type"], "bill", force)


def _next_number(vtype, kind, force=False):
    """Highest numeric voucher number of this type in Tally and in our own log, plus one."""
    c = _next_cache.setdefault(vtype, {"at": 0.0, "max": 0})
    now = time.time()
    if force or now - c["at"] > 120:
        frm, to = _fy_range()
        frm = dt.date(to.year if to.month >= 4 else to.year - 1, 4, 1)
        body = f"""<ENVELOPE>
<HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>VBNums</ID></HEADER>
<BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>{company_vars()}{sv_dates(frm, to + dt.timedelta(days=366))}</STATICVARIABLES>
<TDL><TDLMESSAGE>
<COLLECTION NAME="VBNums" ISMODIFY="No"><TYPE>Voucher</TYPE><FETCH>VoucherNumber,IsCancelled</FETCH><FILTER>VBNumT</FILTER></COLLECTION>
<SYSTEM TYPE="Formulae" NAME="VBNumT">$VoucherTypeName = "{esc(vtype)}"</SYSTEM>
</TDLMESSAGE></TDL></DESC></BODY></ENVELOPE>"""
        mx = 0
        try:
            text = tally_post(body, timeout=60)
            for n in re.findall(r"<VOUCHERNUMBER>\s*(\d+)\s*</VOUCHERNUMBER>", text):
                mx = max(mx, int(n))
        except Exception:
            pass
        c.update(at=now, max=mx)
    mx = c["max"]
    if os.path.exists(LOG_PATH):
        with open(LOG_PATH, encoding="utf-8") as f:
            for line in f:
                try:
                    r = json.loads(line)
                    if r.get("ok") and r.get("kind", "receipt") == kind and str(r.get("receipt_no", "")).isdigit():
                        mx = max(mx, int(r["receipt_no"]))
                except ValueError:
                    pass
    return {"ok": True, "last": mx, "next": str(mx + 1) if mx else ""}


def check_bill(bill_no):
    r = find_vouchers(bill_no)
    if not r.get("ok"):
        return r
    sales = [v for v in r["vouchers"] if "sale" in v["type"].lower() or "invoice" in v["type"].lower()]
    best = sales[0] if sales else None
    other = [f"{v['type']} {v['number']} ({v['party']})" for v in r["vouchers"] if v not in sales]
    return {"ok": True, "bill_no": bill_no, "found": bool(best), "bill": best,
            "note": ("No sales bill with this number. Same number is used by: " + "; ".join(other[:3])) if not best and other else ""}


def check_receipt_no(receipt_no, exclude_master_id=""):
    r = find_vouchers(receipt_no)
    if not r.get("ok"):
        return r
    rec = [v for v in r["vouchers"] if re.search(r"rec(e)?ipt", v["type"].lower())
           and str(v.get("master_id")) != str(exclude_master_id or "")]
    return {"ok": True, "receipt_no": receipt_no, "already_in_tally": bool(rec), "matches": rec}


def ledger_exists(name):
    return any(l["name"].lower() == name.lower() for l in fetch_ledgers(force=True))


def _clean_mobile(m):
    d = re.sub(r"\D", "", str(m or ""))
    return d[-10:] if len(d) >= 10 else d


def _contact_xml(mobile, location):
    x = ""
    if location:
        x += f'<ADDRESS.LIST TYPE="String"><ADDRESS>{esc(location)}</ADDRESS></ADDRESS.LIST>'
    if mobile:
        x += f"<LEDGERMOBILE>{esc(mobile)}</LEDGERMOBILE>"
    return x


def update_contact(ledger, mobile="", location=""):
    _contact_cache["at"] = 0.0
    """Save a customer's mobile number / place on their Tally ledger (only what was given)."""
    mobile, location = _clean_mobile(mobile), " ".join(str(location or "").split())
    if not ledger or not (mobile or location):
        return {"ok": True, "skipped": True}
    inner = f'<LEDGER NAME="{esc(ledger)}" ACTION="Alter"><NAME.LIST><NAME>{esc(ledger)}</NAME></NAME.LIST>{_contact_xml(mobile, location)}</LEDGER>'
    res = import_xml("All Masters", inner)
    ok = res["errors"] == 0 and (res.get("altered", 0) >= 1 or res.get("created", 0) >= 1 or not res["line_errors"])
    if not ok:
        applog("TALLY", "FAIL", f"contact update {ledger}: {res}")
    return {"ok": ok, "tally": res}


def create_party(name, mobile="", location=""):
    _contact_cache["at"] = 0.0
    name = " ".join(name.split()).strip()
    if not name:
        return {"ok": False, "error": "empty name"}
    if ledger_exists(name):
        if mobile or location:
            update_contact(name, mobile, location)
        return {"ok": True, "ledger": name, "note": "already existed"}
    inner = f"""<LEDGER NAME="{esc(name)}" ACTION="Create">
<NAME.LIST><NAME>{esc(name)}</NAME></NAME.LIST>
<PARENT>{esc(CFG['party_group'])}</PARENT>
<ISBILLWISEON>{"Yes" if CFG.get("billwise") else "No"}</ISBILLWISEON>
{_contact_xml(_clean_mobile(mobile), " ".join(str(location or "").split()))}
</LEDGER>"""
    res = import_xml("All Masters", inner)
    _ledger_cache["at"] = 0
    ok = res["created"] >= 1 and res["errors"] == 0
    return {"ok": ok, "ledger": name, "tally": res,
            **({} if ok else {"message": "; ".join(res["line_errors"]) or "Tally did not create the ledger"})}


def already_logged(receipt_no):
    if not receipt_no or not os.path.exists(LOG_PATH):
        return None
    with open(LOG_PATH, encoding="utf-8") as f:
        for line in f:
            try:
                rec = json.loads(line)
            except ValueError:
                continue
            if rec.get("ok") and str(rec.get("receipt_no")) == str(receipt_no):
                return rec
    return None


def log(rec):
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def parse_date(s):
    if not s:
        return dt.date.today()
    s = s.strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d/%m/%y"):
        try:
            return dt.datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    raise ValueError(f"date not understood: {s} (use YYYY-MM-DD)")


def _clean_fields(p):
    f = {
        "party": (p.get("party_ledger") or "").strip(),
        "receipt_no": str(p.get("receipt_no") or "").strip(),
        "mode": (p.get("mode") or "cash").strip().lower(),
        "note": (p.get("narration") or "").strip(),
        "bill_no": str(p.get("bill_no") or "").strip(),
    }
    try:
        f["amount"] = round(float(str(p.get("amount", "")).replace(",", "")), 2)
    except ValueError:
        return None, "amount is not a number"
    if f["amount"] <= 0:
        return None, "amount must be more than 0"
    try:
        f["date"] = parse_date(p.get("date"))
    except ValueError as e:
        return None, str(e)
    f["contra"] = (CFG["mode_ledgers"].get(f["mode"]) or "").strip()
    if not f["contra"]:
        return None, f"no ledger set for mode '{f['mode']}' in config.json"
    if not f["party"]:
        return None, "party_ledger missing"
    if not ledger_exists(f["party"]):
        return None, f"party_not_found: no ledger named '{f['party']}'"
    return f, None


def _alloc(f):
    if not CFG.get("billwise"):
        return "", ""
    ref = ""
    if f["bill_no"]:
        try:
            cb = check_bill(f["bill_no"])
            b = cb.get("bill") or {}
            if cb.get("found") and b.get("party", "").lower() == f["party"].lower():
                ref = b.get("bill_ref") or f["bill_no"]
        except Exception:
            ref = ""
    a = f["amount"]
    if ref:
        return (f"\n<BILLALLOCATIONS.LIST><NAME>{esc(ref)}</NAME><BILLTYPE>Agst Ref</BILLTYPE><AMOUNT>{a:.2f}</AMOUNT></BILLALLOCATIONS.LIST>",
                f"Agst Ref {ref}")
    return (f"\n<BILLALLOCATIONS.LIST><BILLTYPE>On Account</BILLTYPE><AMOUNT>{a:.2f}</AMOUNT></BILLALLOCATIONS.LIST>", "On Account")


def _narration(f):
    if f.get("mode") == "discount":
        return f"Discount / round off on Bill {f['bill_no']}".strip()
    parts = []
    if f["receipt_no"]:
        parts.append(f"Receipt no {f['receipt_no']}")
    if f["bill_no"]:
        parts.append(f"against Bill {f['bill_no']}")
    if f["note"]:
        parts.append(f["note"])
    return ", ".join(parts or ["Receipt"]) + " (voice entry)"


def _voucher_xml(f, action="Create", guid="", vtype=None):
    vtype = vtype or CFG["voucher_type"]
    bill_alloc, alloc_note = _alloc(f)
    amt = f"{f['amount']:.2f}"
    d = f["date"]
    head = f'REMOTEID="{esc(guid)}" ' if guid else ""
    num = f"\n<VOUCHERNUMBER>{esc(f['receipt_no'])}</VOUCHERNUMBER>" if f["receipt_no"] and CFG.get("receipt_no_as_voucher_number", True) else ""
    xml = f"""<VOUCHER {head}VCHTYPE="{esc(vtype)}" ACTION="{action}" OBJVIEW="Accounting Voucher View">
<DATE>{d:%Y%m%d}</DATE>
<EFFECTIVEDATE>{d:%Y%m%d}</EFFECTIVEDATE>
<VOUCHERTYPENAME>{esc(vtype)}</VOUCHERTYPENAME>{num}
<REFERENCE>{esc(f['receipt_no'])}</REFERENCE>
<NARRATION>{esc(_narration(f))}</NARRATION>
<PARTYLEDGERNAME>{esc(f['party'])}</PARTYLEDGERNAME>
<PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW>
<ALLLEDGERENTRIES.LIST>
<LEDGERNAME>{esc(f['party'])}</LEDGERNAME>
<ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
<ISPARTYLEDGER>Yes</ISPARTYLEDGER>
<AMOUNT>{amt}</AMOUNT>{bill_alloc}
</ALLLEDGERENTRIES.LIST>
<ALLLEDGERENTRIES.LIST>
<LEDGERNAME>{esc(f['contra'])}</LEDGERNAME>
<ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
<AMOUNT>-{amt}</AMOUNT>
</ALLLEDGERENTRIES.LIST>
</VOUCHER>"""
    return xml, alloc_note


def _log_rec(f, ok, res, alloc_note, action="create", replaces="", master_id=""):
    return {
        "ok": ok, "action": action, "posted_at": dt.datetime.now().isoformat(timespec="seconds"),
        "receipt_no": f["receipt_no"], "party_ledger": f["party"], "amount": f["amount"],
        "date": f["date"].isoformat(), "mode": f["mode"], "bill_no": f["bill_no"], "alloc": alloc_note,
        "master_id": str(master_id or res.get("last_vch_id") or ""), "replaces": str(replaces or ""),
        "vtype": CFG["voucher_type"], "tally": res,
    }


def create_receipt(p):
    force = bool(p.get("allow_duplicate"))
    with _lock:
        f, err = _clean_fields(p)
        if err:
            return {"ok": False, "error": err.split(":")[0], "message": err}
        if f["receipt_no"] and not force:
            dup = already_logged(f["receipt_no"])
            if dup:
                return {"ok": False, "error": "duplicate_receipt",
                        "message": f"Receipt {f['receipt_no']} was already posted on {dup.get('posted_at')} for {dup.get('party_ledger')} Rs {dup.get('amount')}."}
            try:
                tc = check_receipt_no(f["receipt_no"])
                if tc.get("already_in_tally"):
                    m = tc["matches"][0]
                    return {"ok": False, "error": "duplicate_receipt",
                            "message": f"Receipt {f['receipt_no']} is already in Tally: {m['party']} Rs {m['amount']} on {m['date']} ({m['type']})."}
            except Exception:
                pass
        xml, alloc_note = _voucher_xml(f, "Create")
        res = import_xml("Vouchers", xml)
        ok = res["created"] >= 1 and res["errors"] == 0 and res["exceptions"] == 0
        log(_log_rec(f, ok, res, alloc_note))
        if ok:
            return {"ok": True, "message": f"Receipt {f['receipt_no']} posted: {f['party']}, Rs {f['amount']:.2f}, {f['date']:%d-%m-%Y}" + (f", {alloc_note}" if alloc_note else ""),
                    "tally_voucher_id": res["last_vch_id"]}
        hint = " (Tally refused it: often a duplicate receipt number in this series)" if res.get("exceptions") else ""
        return {"ok": False, "error": "tally_rejected", "message": ("; ".join(res["line_errors"]) or "Tally rejected the entry") + hint, "tally": res}


def load_receipt(master_id="", date_iso="", receipt_no=""):
    v = None
    if master_id:
        v = get_voucher(master_id, date_iso)
    elif receipt_no:
        r = check_receipt_no(receipt_no)
        if r.get("ok") and r["matches"]:
            v = r["matches"][0]
    if not v:
        return {"ok": False, "error": "not_found", "message": "This entry was not found in Tally."}
    if v.get("cancelled"):
        return {"ok": False, "error": "cancelled", "message": "This entry is cancelled in Tally."}
    mode = next((k for k, led in CFG["mode_ledgers"].items() if led and led.lower() == v["contra"].lower()), "cash")
    bill_no = ""
    m = re.search(r"against Bill (\S+)|B\.?No\.?\s*(\S+)", v["narration"], re.I)
    if m:
        bill_no = (m.group(1) or m.group(2)).strip(",.")
    note = re.sub(r"\s*\(voice entry\)\s*$", "", v["narration"])
    note = re.sub(r"^(Receipt no \S+,?\s*)?(against Bill \S+,?\s*)?(B\.?No\.?\s*\S+\s*)?", "", note, flags=re.I).strip(" ,")
    return {"ok": True, "master_id": v["master_id"], "type": v["type"], "orig_date": v["date_iso"],
            "draft": {"receipt_no": v["number"] or v["reference"], "bill_no": bill_no, "amount": f"{v['amount']:g}",
                      "mode": mode, "name": "", "ledger": v["party"], "date": v["date_iso"], "note": note},
            "bill_ref": v["bill_ref"], "bill_type": v["bill_type"], "same_type": v["type"].lower() == CFG["voucher_type"].lower()}


def _delete_voucher(old):
    """Delete a voucher by its MasterID (falls back to GUID). Returns True if it is gone from Tally."""
    od = parse_date(old["date_iso"])
    attempts = [
        f'<VOUCHER DATE="{od:%Y%m%d}" TAGNAME="MasterID" TAGVALUE="{esc(old["master_id"])}" VCHTYPE="{esc(old["type"])}" ACTION="Delete"></VOUCHER>',
        f"""<VOUCHER REMOTEID="{esc(old['guid'])}" VCHTYPE="{esc(old['type'])}" ACTION="Delete">
<DATE>{od:%Y%m%d}</DATE><VOUCHERTYPENAME>{esc(old['type'])}</VOUCHERTYPENAME></VOUCHER>""",
    ]
    results = []
    for xml in attempts:
        try:
            results.append(import_xml("Vouchers", xml))
        except Exception as e:
            results.append({"error": str(e)})
        still = get_voucher(old["master_id"], old["date_iso"])
        if not still:
            return True, results
    return False, results


def update_receipt(p):
    """Edit = make a fresh entry with the changes, then delete the old entry."""
    mid = str(p.get("master_id") or "").strip()
    if not mid:
        return {"ok": False, "error": "master_id missing"}
    with _lock:
        old = get_voucher(mid, p.get("orig_date", ""))
        if not old or old.get("cancelled"):
            return {"ok": False, "error": "not_found", "message": "Original entry not found in Tally."}
        f, err = _clean_fields(p)
        if err:
            return {"ok": False, "error": err.split(":")[0], "message": err}
        if f["receipt_no"] and not p.get("allow_duplicate"):
            tc = check_receipt_no(f["receipt_no"], exclude_master_id=mid)
            if tc.get("already_in_tally"):
                m = tc["matches"][0]
                return {"ok": False, "error": "duplicate_receipt",
                        "message": f"Receipt {f['receipt_no']} is already used in Tally: {m['party']} Rs {m['amount']} on {m['date']}."}
        # Tally blocks duplicate receipt numbers, so: 1) remove old, 2) create corrected, 3) restore old if 2 fails
        gone, del_res = _delete_voucher(old)
        if not gone:
            log(_log_rec(f, False, {"created": 0, "altered": 0, "errors": 0, "exceptions": 0, "last_vch_id": 0, "line_errors": []},
                         "", action="edit", replaces=mid))
            return {"ok": False, "error": "delete_failed",
                    "message": f"Could not remove the old entry ({old['type']} {old['number']}, {old['date']}). Nothing was changed.",
                    "delete_result": del_res}
        xml, alloc_note = _voucher_xml(f, "Create")
        res = import_xml("Vouchers", xml)
        ok = res["created"] >= 1 and res["errors"] == 0 and res["exceptions"] == 0
        if not ok:
            restored = _restore_voucher(old)
            log(_log_rec(f, False, res, alloc_note, action="edit", replaces=mid))
            return {"ok": False, "error": "tally_rejected", "tally": res, "restored_old": restored,
                    "message": ("Tally did not accept the corrected entry. " +
                                ("The old entry was put back." if restored else
                                 f"IMPORTANT: the old entry could not be put back: {old['type']} {old['number']}, {old['party']}, Rs {old['amount']}, {old['date']}. Please re-enter it."))}
        new_mid = str(res.get("last_vch_id") or "")
        rec = _log_rec(f, True, res, alloc_note, action="edit", replaces=mid, master_id=new_mid)
        rec["old"] = {k: old[k] for k in ("type", "number", "date_iso", "party", "amount", "bill_ref", "bill_type", "contra", "narration")}
        log(rec)
        return {"ok": True, "master_id": new_mid,
                "message": f"Receipt {f['receipt_no']} corrected: {f['party']}, Rs {f['amount']:.2f}, {f['date']:%d-%m-%Y} ({alloc_note}). Old entry replaced."}


def _restore_voucher(old):
    """Re-create a deleted voucher from what we read before deleting it."""
    try:
        od = parse_date(old["date_iso"])
        amt = f"{old['amount']:.2f}"
        if old.get("bill_type") == "Agst Ref" and old.get("bill_ref"):
            alloc = f"\n<BILLALLOCATIONS.LIST><NAME>{esc(old['bill_ref'])}</NAME><BILLTYPE>Agst Ref</BILLTYPE><AMOUNT>{amt}</AMOUNT></BILLALLOCATIONS.LIST>"
        elif CFG.get("billwise"):
            alloc = f"\n<BILLALLOCATIONS.LIST><BILLTYPE>On Account</BILLTYPE><AMOUNT>{amt}</AMOUNT></BILLALLOCATIONS.LIST>"
        else:
            alloc = ""
        num = f"\n<VOUCHERNUMBER>{esc(old['number'])}</VOUCHERNUMBER>" if old.get("number") else ""
        xml = f"""<VOUCHER VCHTYPE="{esc(old['type'])}" ACTION="Create" OBJVIEW="Accounting Voucher View">
<DATE>{od:%Y%m%d}</DATE>
<EFFECTIVEDATE>{od:%Y%m%d}</EFFECTIVEDATE>
<VOUCHERTYPENAME>{esc(old['type'])}</VOUCHERTYPENAME>{num}
<NARRATION>{esc(old.get('narration', ''))}</NARRATION>
<PARTYLEDGERNAME>{esc(old['party'])}</PARTYLEDGERNAME>
<PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW>
<ALLLEDGERENTRIES.LIST>
<LEDGERNAME>{esc(old['party'])}</LEDGERNAME>
<ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
<ISPARTYLEDGER>Yes</ISPARTYLEDGER>
<AMOUNT>{amt}</AMOUNT>{alloc}
</ALLLEDGERENTRIES.LIST>
<ALLLEDGERENTRIES.LIST>
<LEDGERNAME>{esc(old.get('contra') or CFG['mode_ledgers']['cash'])}</LEDGERNAME>
<ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
<AMOUNT>-{amt}</AMOUNT>
</ALLLEDGERENTRIES.LIST>
</VOUCHER>"""
        r = import_xml("Vouchers", xml)
        return r["created"] >= 1 and r["errors"] == 0
    except Exception:
        return False


# ================================================================ VOICE / DICTATION -> FIELDS
# Two ways besides the ElevenLabs agent:
#   "scribe": the screen records each spoken sentence, we transcribe it with ElevenLabs Scribe (batch API)
#   "text"  : any dictation app (Wispr Flow etc.) types a sentence into a box
# Both sentences go to Claude, which turns them into the same field updates the agent makes.

USAGE_PATH = os.path.join(HERE, "usage.jsonl")
PRICES = {"scribe_per_hour": 0.22, "claude_in_per_m": 1.0, "claude_out_per_m": 5.0}


def _usage(kind, **kw):
    try:
        with open(USAGE_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps({"t": dt.datetime.now().isoformat(timespec="seconds"), "kind": kind, **kw}) + "\n")
    except Exception:
        pass


def usage_summary():
    today, month = dt.date.today().isoformat(), dt.date.today().isoformat()[:7]
    out = {"today": {"usd": 0.0, "scribe_sec": 0.0, "claude_calls": 0}, "month": {"usd": 0.0, "scribe_sec": 0.0, "claude_calls": 0}}
    if os.path.exists(USAGE_PATH):
        with open(USAGE_PATH, encoding="utf-8") as f:
            for line in f:
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                for key, pref in (("today", today), ("month", month)):
                    if r.get("t", "").startswith(pref):
                        o = out[key]
                        o["usd"] += float(r.get("usd") or 0)
                        if r.get("kind") == "scribe":
                            o["scribe_sec"] += float(r.get("seconds") or 0)
                        if r.get("kind") == "claude":
                            o["claude_calls"] += 1
    rate = float(CFG.get("usd_inr") or 88)
    for o in out.values():
        o["inr"] = round(o["usd"] * rate, 2)
        o["usd"] = round(o["usd"], 4)
    out["usd_inr"] = rate
    return out


def _wav_seconds(b):
    try:
        if b[:4] == b"RIFF":
            rate = int.from_bytes(b[24:28], "little")
            bps = int.from_bytes(b[34:36], "little") // 8 * int.from_bytes(b[22:24], "little")
            return max(0.0, (len(b) - 44) / float(rate * bps))
    except Exception:
        pass
    return len(b) / 32000.0


# ---------------------------------------------------------------- cloud (our keys, never on the shop PC)
_cloud_lock = threading.Lock()


def set_config(**kv):
    """Write a few keys into config.json (keeps everything else)."""
    cur = {}
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cur = json.load(f)
    cur.update(kv)
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cur, f, ensure_ascii=False, indent=2)
    os.replace(tmp, CONFIG_PATH)
    CFG.update(kv)


def cloud_register(force=False):
    with _cloud_lock:
        if CFG.get("device_id") and CFG.get("device_secret") and not force:
            return True
        if not CFG.get("cloud_url"):
            return False
        install = CFG.get("install_id") or ("tv-" + os.urandom(12).hex())
        body = {"install_id": install, "version": app_version(),
                "shop": CFG.get("shop_name") or CFG.get("company") or shop_print().get("name_hi") or "",
                "machine": os.environ.get("COMPUTERNAME", "")}
        req = urllib.request.Request(CFG["cloud_url"].rstrip("/") + "/register", data=json.dumps(body).encode(),
                                     method="POST", headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                res = json.loads(r.read().decode("utf-8"))
        except Exception as e:
            applog("CLOUD", "FAIL", f"register: {e}")
            return False
        if not res.get("ok"):
            applog("CLOUD", "FAIL", f"register: {res}")
            return False
        set_config(install_id=install, device_id=res["device_id"], device_secret=res["secret"])
        applog("CLOUD", "OK", f"registered {res['device_id']}")
        return True


def cloud_call(path, data, content_type="application/json", query="", timeout=60, _retry=True):
    """POST to our cloud proxy. Returns (status, parsed_json)."""
    if not cloud_register():
        return 0, {"error": "offline", "message": "इंटरनेट/सर्वर से जुड़ नहीं पाए"}
    url = CFG["cloud_url"].rstrip("/") + path + (("?" + query) if query else "")
    req = urllib.request.Request(url, data=data, method="POST", headers={
        "Content-Type": content_type, "x-tv-device": CFG["device_id"], "x-tv-secret": CFG["device_secret"],
        "x-tv-version": app_version()})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", "replace")
        try:
            res = json.loads(raw)
        except ValueError:
            res = {"error": f"http_{e.code}", "message": raw[:300]}
        if e.code == 401 and _retry and res.get("error") in ("bad_device", "not_registered"):
            cloud_register(force=True)
            return cloud_call(path, data, content_type, query, timeout, _retry=False)
        applog("CLOUD", "FAIL", f"{path} {e.code} {raw[:300]}")
        return e.code, res
    except Exception as e:
        applog("CLOUD", "FAIL", f"{path} {e}")
        return 0, {"error": "offline", "message": "इंटरनेट से जुड़ नहीं पाए"}


_CLOUD_MSG = {"daily_limit": "आज की सीमा पूरी हो गई", "blocked": "सेवा बंद है · Letsbloc से संपर्क करें",
              "server_not_ready": "सर्वर अभी तैयार नहीं · थोड़ी देर में", "offline": "इंटरनेट से जुड़ नहीं पाए"}


def _cloud_err(status, res):
    code = res.get("error") or (res.get("detail") or {}).get("status") or f"http_{status}"
    return {"ok": False, "error": code, "message": _CLOUD_MSG.get(code) or res.get("message") or str(res)[:200]}


def transcribe(audio, content_type="audio/wav"):
    key = (CFG.get("elevenlabs_api_key") or "").strip()
    secs = _wav_seconds(audio)
    if not key:
        q = ("language=" + CFG["scribe_language"]) if CFG.get("scribe_language") else ""
        st, res = cloud_call("/transcribe", audio, content_type, q)
        if st != 200 or "text" not in res:
            return _cloud_err(st, res)
        _usage("scribe", seconds=round(secs, 2), usd=round(secs / 3600 * PRICES["scribe_per_hour"], 6), via="cloud")
        return {"ok": True, "text": (res.get("text") or "").strip(), "language": res.get("language_code"), "seconds": round(secs, 2)}
    boundary = "----tv" + os.urandom(8).hex()
    ext = "wav" if "wav" in content_type else "webm"
    parts = []

    def field(name, value):
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode())
    field("model_id", CFG.get("scribe_model") or "scribe_v2")
    if CFG.get("scribe_language"):
        field("language_code", CFG["scribe_language"])
    field("tag_audio_events", "false")
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="speech.{ext}"\r\nContent-Type: {content_type}\r\n\r\n'.encode()
                 + audio + b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode())
    req = urllib.request.Request("https://api.elevenlabs.io/v1/speech-to-text", data=b"".join(parts), method="POST",
                                 headers={"xi-api-key": key, "Content-Type": f"multipart/form-data; boundary={boundary}"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            res = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        msg = e.read().decode("utf-8", "replace")[:400]
        applog("SCRIBE", "FAIL", f"{e.code} {msg}")
        return {"ok": False, "error": f"scribe_{e.code}", "message": msg}
    _usage("scribe", seconds=round(secs, 2), usd=round(secs / 3600 * PRICES["scribe_per_hour"], 6))
    return {"ok": True, "text": (res.get("text") or "").strip(), "language": res.get("language_code"), "seconds": round(secs, 2)}


_FIELD_PROPS = {
    "receipt_no": {"type": "string", "description": "Receipt tab: printed receipt number, digits"},
    "bill_no": {"type": "string", "description": "Receipt tab: bill the payment is against. Bill tab: this bill's number"},
    "amount": {"type": "string", "description": "Receipt tab: amount received. Bill tab: price of THIS item only (gems/other, or no weight). Digits"},
    "mode": {"type": "string", "enum": ["cash", "upi", "bank"], "description": "Receipt tab: payment mode"},
    "name": {"type": "string", "description": "Customer name in English letters (transliterate Hindi), e.g. 'Hari Bai'"},
    "date": {"type": "string", "description": "YYYY-MM-DD, only if a date was said"},
    "note": {"type": "string", "description": "Short note"},
    "metal": {"type": "string", "enum": ["gold", "silver", "other"], "description": "Bill tab: sona=gold, chandi=silver, gems/stones=other"},
    "karat": {"type": "string", "enum": ["24", "22", "20", "18", "14"], "description": "Bill tab, gold only"},
    "item": {"type": "string", "description": "Bill tab: ONE item's short name as in Tally, without karat"},
    "weight": {"type": "string", "description": "Bill tab: grams, digits e.g. '10.35'"},
    "rate": {"type": "string", "description": "Bill tab: rupees per gram, only if said"},
    "making_pct": {"type": "string", "description": "Bill tab: making %, only if said"},
    "tax_pct": {"type": "string", "description": "Bill tab: tax %, only if said"},
    "new_item": {"type": "boolean", "description": "Bill tab: force a new row for a repeated item name"},
    "remove_item": {"type": "string", "description": "Bill tab: item name or row number to remove"},
    "discount": {"type": "string", "description": "Bill tab: discount in rupees"},
    "round_to": {"type": "string", "enum": ["10", "50", "100", "500", "1000"], "description": "Bill tab: round total down to this"},
    "paid": {"type": "string", "description": "Bill tab: money paid now with the bill (jama)"},
    "paid_mode": {"type": "string", "enum": ["cash", "upi", "bank"]},
    "mobile": {"type": "string", "description": "Customer mobile, 10 digits"},
    "location": {"type": "string", "description": "Customer village/town in English letters"},
    "clear": {"type": "boolean", "description": "true only if staff ask to empty the card"},
}

_PARSE_TOOL = {
    "name": "fill_card",
    "description": "Turn what the shop staff said into updates for the entry card on screen.",
    "input_schema": {
        "type": "object",
        "properties": {
            "updates": {"type": "array", "description": "One object per change, in order. For bills: one object per item.",
                        "items": {"type": "object", "properties": _FIELD_PROPS}},
            "action": {"type": "string", "enum": ["none", "post", "load", "clear"],
                       "description": "post = staff clearly asked to save/enter it now (entry kar do, kar do, theek hai daal do, agla). load = open an existing entry by number. Otherwise none."},
            "load_no": {"type": "string", "description": "For action=load: the receipt/bill number to open"},
            "heard": {"type": "string", "description": "The sentence cleaned up, in Hindi/English as spoken (for the screen log)"},
        },
        "required": ["updates", "action"],
    },
}


def parse_dictation(text, tab="receipt", card=None):
    key = (CFG.get("anthropic_api_key") or "").strip()
    text = (text or "").strip()[:2000]
    if not text:
        return {"ok": True, "updates": [], "action": "none"}
    gold = "Ltkn, Bali, Tops, Chain, Ring, Pendent, Long, Mangalsutra, Jhale, Mni, Mukhda, Dorla"
    silver = "Chain, Pairpatti, Payal, Jodve, Bichhia, Kada, Locket"
    system = f"""You fill a data-entry card for an Indian jewellery shop ({CFG.get("shop_name") or CFG.get("company") or "a jewellery shop"}) that posts into TallyPrime.
Staff speak Hindi/Hinglish. Today is {dt.date.today().isoformat()}. The open tab is: {tab.upper()}.
RECEIPT tab = money received from a customer: receipt_no, bill_no, amount, mode (cash default), name, date, note.
BILL tab = a sale bill: bill_no, name, mobile, location, then items one by one (metal, karat for gold, item, weight in grams; rate only if said), then discount/round_to and paid.
Gold item names (as in Tally): {gold}. Silver item names: {silver}. Map spoken words to these names (e.g. latkan->Ltkn, mani->Mni, pendant->Pendent, bichiya->Bichhia, payal/pajeb->Payal, pairpatti->Pairpatti).
Rules: names of people in English letters, Title Case. Numbers as digits (das hazaar -> 10000, sava -> .25, sadhe -> +.5, paune -> -.25 of the next unit). Weight in grams (tola = 11.66 g only if said). Only include fields actually said; never invent amounts. Corrections replace earlier values. Never send a bill total as an item amount.
Current card: {json.dumps(card or {}, ensure_ascii=False)[:1500]}"""
    body = {"model": CFG.get("claude_model") or "claude-haiku-4-5", "max_tokens": 700, "system": system,
            "tools": [_PARSE_TOOL], "tool_choice": {"type": "tool", "name": "fill_card"},
            "messages": [{"role": "user", "content": text}]}
    if not key:
        st, res = cloud_call("/claude", json.dumps(body).encode("utf-8"), timeout=45)
        if st != 200 or "content" not in res:
            return _cloud_err(st, res)
    else:
        req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps(body).encode("utf-8"), method="POST",
                                     headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=40) as r:
                res = json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            msg = e.read().decode("utf-8", "replace")[:400]
            applog("CLAUDE", "FAIL", f"{e.code} {msg}")
            return {"ok": False, "error": f"claude_{e.code}", "message": msg}
    u = res.get("usage") or {}
    tin, tout = int(u.get("input_tokens") or 0), int(u.get("output_tokens") or 0)
    _usage("claude", tokens_in=tin, tokens_out=tout,
           usd=round(tin / 1e6 * PRICES["claude_in_per_m"] + tout / 1e6 * PRICES["claude_out_per_m"], 6))
    out = next((b.get("input") for b in res.get("content", []) if b.get("type") == "tool_use"), None) or {}
    return {"ok": True, "updates": out.get("updates") or [], "action": out.get("action") or "none",
            "load_no": out.get("load_no") or "", "heard": out.get("heard") or text}


def save_settings(p):
    """Save API keys / input options typed on this PC into config.json (local only)."""
    allowed = {"elevenlabs_api_key", "anthropic_api_key", "claude_model", "scribe_language", "usd_inr"}
    cur = {}
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cur = json.load(f)
    for k, v in (p or {}).items():
        if k in allowed and v is not None and str(v).strip() != "":
            cur[k] = str(v).strip()
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cur, f, ensure_ascii=False, indent=2)
    os.replace(tmp, CONFIG_PATH)
    CFG.update(cur)
    return {"ok": True, **settings_view()}


def settings_view():
    def mask(k):
        v = (CFG.get(k) or "").strip()
        return ("…" + v[-4:]) if v else ""
    out = {"version": app_version(), "admin": bool(CFG.get("admin")), "onboarded": bool(CFG.get("onboarded")),
           "cloud": bool(CFG.get("device_id"))}
    if CFG.get("admin"):
        out.update({"elevenlabs_key": mask("elevenlabs_api_key"), "anthropic_key": mask("anthropic_api_key"),
                    "claude_model": CFG.get("claude_model") or "claude-haiku-4-5"})
    return out


def app_version():
    try:
        with open(os.path.join(HERE, "VERSION"), encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return "dev"


# ================================================================ UPDATER
# Checks a small public version file; if a newer build exists it downloads the zip, checks its SHA-256,
# test-compiles the new bridge.py, keeps a backup of the files it replaces, then swaps them in.
# The bridge restarts itself when bridge.py changes; the screen reloads when it is idle.
# Never touched: config.json, logs, printed bills, the receipts/bills log, window data.

DEFAULT_UPDATE_URL = "https://raw.githubusercontent.com/yashverma38/tally-voice-updates/main/latest.json"
UPDATE_DIR = os.path.join(HERE, "updates")
PROTECTED = {"config.json", "receipts_log.jsonl", "usage.jsonl", "app.log", "app.log.old", "bridge.log", "window_err.log",
             "window_lib_attempt.txt"}
PROTECTED_DIRS = {"printed", "jobs", "window_data", "updates"}
UPDATE_STATE = {"status": "idle", "latest": "", "message": "", "checked_at": ""}
_last_activity = {"t": 0.0}


def _vtuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v or "0"))[:3]) or (0,)


def _fetch(url, timeout=60):
    sep = "&" if "?" in url else "?"
    req = urllib.request.Request(url + f"{sep}t={int(time.time())}", headers={"User-Agent": "TallyVoice-Updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def check_update(apply=True, force=False):
    import hashlib
    import zipfile
    import io
    import py_compile
    import shutil
    UPDATE_STATE.update(status="checking", checked_at=dt.datetime.now().isoformat(timespec="seconds"), message="")
    try:
        info = json.loads(_fetch(CFG.get("update_url") or DEFAULT_UPDATE_URL, 30).decode("utf-8"))
    except Exception as e:
        UPDATE_STATE.update(status="offline", message=f"update check failed: {e}")
        return dict(UPDATE_STATE)
    cur, new = app_version(), str(info.get("version") or "")
    UPDATE_STATE["latest"] = new
    if _vtuple(new) <= _vtuple(cur) and not force:
        UPDATE_STATE.update(status="up_to_date", message=f"{cur} सबसे नया है")
        return dict(UPDATE_STATE)
    if not apply:
        UPDATE_STATE.update(status="available", message=f"नया {new} उपलब्ध")
        return dict(UPDATE_STATE)
    try:
        blob = _fetch(info["url"], 300)
        if hashlib.sha256(blob).hexdigest().lower() != str(info.get("sha256", "")).lower():
            raise ValueError("download is damaged (checksum mismatch)")
        z = zipfile.ZipFile(io.BytesIO(blob))
        names = [n for n in z.namelist() if not n.endswith("/")]
        if "bridge.py" not in names or "ui.html" not in names:
            raise ValueError("update package is incomplete")
        stage = os.path.join(UPDATE_DIR, "staging")
        shutil.rmtree(stage, ignore_errors=True)
        os.makedirs(stage, exist_ok=True)
        z.extractall(stage)
        py_compile.compile(os.path.join(stage, "bridge.py"), doraise=True)    # never install a bridge that cannot start
        backup = os.path.join(UPDATE_DIR, f"backup-{cur}")
        os.makedirs(backup, exist_ok=True)
        changed = []
        for n in sorted(names, key=lambda x: (x == "bridge.py", x == "VERSION")):    # bridge.py + VERSION last
            parts = n.replace("\\", "/").split("/")
            if parts[0] in PROTECTED_DIRS or n in PROTECTED or ".." in parts:
                continue
            dst = os.path.join(HERE, *parts)
            src = os.path.join(stage, *parts)
            if os.path.exists(dst):
                with open(dst, "rb") as a, open(src, "rb") as b:
                    if a.read() == b.read():
                        continue
                bk = os.path.join(backup, *parts)
                os.makedirs(os.path.dirname(bk), exist_ok=True)
                shutil.copy2(dst, bk)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            try:
                tmp = dst + ".new"
                shutil.copy2(src, tmp)
                os.replace(tmp, dst)
                changed.append(n)
            except OSError as e:                     # e.g. Tally Voice.exe in use: skip, next update will retry
                applog("UPDATE", "WARN", f"could not replace {n}: {e}")
        if "VERSION" not in names:
            with open(os.path.join(HERE, "VERSION"), "w", encoding="utf-8") as f:
                f.write(new)
        applog("UPDATE", "OK", f"{cur} -> {new}: {', '.join(changed) or 'no file changes'}")
        UPDATE_STATE.update(status="updated", message=f"{new} लग गया", latest=new)
    except Exception as e:
        applog("UPDATE", "FAIL", f"{cur} -> {new}: {type(e).__name__}: {e}")
        UPDATE_STATE.update(status="failed", message=str(e))
    return dict(UPDATE_STATE)


def rollback_update():
    """Put back the files saved before the most recent update."""
    import shutil
    if not os.path.isdir(UPDATE_DIR):
        return {"ok": False, "message": "no backup"}
    backups = sorted((d for d in os.listdir(UPDATE_DIR) if d.startswith("backup-")),
                     key=lambda d: os.path.getmtime(os.path.join(UPDATE_DIR, d)))
    if not backups:
        return {"ok": False, "message": "no backup"}
    b = os.path.join(UPDATE_DIR, backups[-1])
    restored = []
    for root, _, files in os.walk(b):
        for fn in sorted(files, key=lambda x: x == "bridge.py"):
            src = os.path.join(root, fn)
            rel = os.path.relpath(src, b)
            shutil.copy2(src, os.path.join(HERE, rel))
            restored.append(rel)
    with open(os.path.join(HERE, "VERSION"), "w", encoding="utf-8") as f:
        f.write(backups[-1][len("backup-"):])
    applog("UPDATE", "ROLLBACK", f"restored {backups[-1]}: {restored}")
    return {"ok": True, "restored": restored}


def update_loop():
    time.sleep(90)
    while True:
        if CFG.get("auto_update", True):
            if time.time() - _last_activity["t"] < 180:     # someone is entering right now: try again shortly
                time.sleep(300)
                continue
            try:
                check_update(apply=True)
            except Exception as e:
                applog("UPDATE", "FAIL", f"{type(e).__name__}: {e}")
        time.sleep(6 * 3600)


# ================================================================ PRINT (A5)

PRINT_DIR = os.path.join(HERE, "printed")
_company_cache = {"at": 0.0, "info": None}


def company_info():
    if _company_cache["info"] and time.time() - _company_cache["at"] < 3600:
        return _company_cache["info"]
    info = {"name": "", "address": [], "phone": "", "mobile": "", "email": "", "gstin": "", "state": "", "pincode": ""}
    try:
        body = f"""<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>VBCo</ID></HEADER>
<BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>{company_vars()}</STATICVARIABLES>
<TDL><TDLMESSAGE><COLLECTION NAME="VBCo" ISMODIFY="No"><TYPE>Company</TYPE>
<FETCH>Name,Address,PhoneNumber,MobileNumbers,Email,GSTRegistrationNumber,StateName,PinCode</FETCH></COLLECTION></TDLMESSAGE></TDL>
</DESC></BODY></ENVELOPE>"""
        root = ET.fromstring(tally_post(body))
        c = next(iter(root.iter("COMPANY")), None)
        if c is not None:
            g = lambda t: html.unescape((c.findtext(t) or "").strip())
            info.update(name=c.get("NAME") or g("NAME"), phone=g("PHONENUMBER"), email=g("EMAIL"),
                        gstin=g("GSTREGISTRATIONNUMBER"), state=g("STATENAME"), pincode=g("PINCODE"),
                        address=[html.unescape(a.text.strip()) for a in c.iter("ADDRESS") if a.text and a.text.strip()],
                        mobile=", ".join(html.unescape(m.text.strip()) for m in c.iter("MOBILENUMBERS") if m.text and m.text.strip()))
    except Exception:
        pass
    shop = CFG.get("shop") or {}
    for k, v in shop.items():          # anything set in config.json wins
        if v:
            info[k] = v
    if not info["name"]:
        info["name"] = "Verma Jewellers"
    _company_cache.update(at=time.time(), info=info)
    return info


def party_contact(ledger):
    try:
        body = f"""<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Object</TYPE><SUBTYPE>Ledger</SUBTYPE><ID TYPE="Name">{esc(ledger)}</ID></HEADER>
<BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>{company_vars()}</STATICVARIABLES>
<FETCHLIST><FETCH>Name</FETCH><FETCH>Address</FETCH><FETCH>LedgerMobile</FETCH><FETCH>LedgerPhone</FETCH><FETCH>PinCode</FETCH><FETCH>ClosingBalance</FETCH></FETCHLIST>
</DESC></BODY></ENVELOPE>"""
        t = tally_post(body)
        g = lambda tag: html.unescape((re.search(rf"<{tag}[^>]*>([^<]*)</{tag}>", t) or [None, ""])[1].strip())
        addr = [html.unescape(a) for a in re.findall(r"<ADDRESS[^>]*>([^<]+)</ADDRESS>", t) if a.strip()]
        bal = _amt(g("CLOSINGBALANCE"))
        return {"mobile": g("LEDGERMOBILE") or g("LEDGERPHONE"), "address": addr, "pincode": g("PINCODE"),
                "balance": abs(bal), "balance_side": "Dr" if bal < 0 else ("Cr" if bal > 0 else "")}
    except Exception:
        return {"mobile": "", "address": [], "pincode": "", "balance": 0, "balance_side": ""}


_ONES = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve",
         "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"]
_TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]


def _two(n):
    return _ONES[n] if n < 20 else (_TENS[n // 10] + (" " + _ONES[n % 10] if n % 10 else ""))


def _three(n):
    h, r = divmod(n, 100)
    return ((_ONES[h] + " Hundred" + (" " if r else "")) if h else "") + (_two(r) if r else "")


def rupees_in_words(x):
    n = int(round(float(x) * 100))
    rs, ps = divmod(n, 100)
    if rs == 0 and ps == 0:
        return "Rupees Zero Only"
    parts = []
    crore, rs = divmod(rs, 10000000)
    lakh, rs = divmod(rs, 100000)
    thousand, rs = divmod(rs, 1000)
    if crore:
        parts.append(_three(crore) + " Crore")
    if lakh:
        parts.append(_two(lakh) + " Lakh")
    if thousand:
        parts.append(_two(thousand) + " Thousand")
    if rs:
        parts.append(_three(rs))
    words = "Rupees " + " ".join(parts) if parts else "Rupees Zero"
    if ps:
        words += " and " + _two(ps) + " Paise"
    return words + " Only"


def _inr(x):
    n = float(x)
    neg = n < 0
    whole, frac = f"{abs(n):.2f}".split(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups + [tail])
    return ("-" if neg else "") + "₹" + whole + ("." + frac if frac != "00" else "")


def _log_extra(master_id):
    """Fields we stored when the entry was made (item, bill no, mode...)."""
    found = {}
    if os.path.exists(LOG_PATH):
        with open(LOG_PATH, encoding="utf-8") as f:
            for line in f:
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                if r.get("ok") and str(r.get("master_id") or r.get("tally", {}).get("last_vch_id") or "") == str(master_id):
                    found = r
    return found


def bill_payments(bill_no, party, want=None):
    """Receipts (or with want="discount", discounts) entered against this bill, from this PC's log."""
    if not bill_no or not os.path.exists(LOG_PATH):
        return []
    by_no = {}
    with open(LOG_PATH, encoding="utf-8") as f:
        for line in f:
            try:
                r = json.loads(line)
            except ValueError:
                continue
            if r.get("ok") and r.get("kind") == want and str(r.get("bill_no") or "") == str(bill_no) \
                    and (r.get("party_ledger") or "").lower() == (party or "").lower():
                d = str(r.get("date") or "")
                try:
                    d = dt.date.fromisoformat(d[:10]).strftime("%d-%m-%Y")
                except ValueError:
                    pass
                key = str(r.get("receipt_no") or r.get("master_id"))
                if r.get("removed"):
                    by_no.pop(key, None)
                    continue
                by_no[key] = {
                    "receipt_no": str(r.get("receipt_no") or ""), "amount": float(r.get("amount") or 0),
                    "mode": (r.get("mode") or "cash").lower(), "date": d,
                    "master_id": str(r.get("master_id") or ""), "date_iso": str(r.get("date") or "")[:10]}
    return list(by_no.values())


# Shop details printed on bills/receipts (same as the printed bill book). config.json "shop_print" can override any of these.
SHOP_PRINT = {
    "name_hi": "वर्मा ज्वेलर्स",
    "tagline": "सोने, चांदी के आभुषणों के क्रेता एवं विक्रेता",
    "address": "पता : जय स्तंभ से गांधी चौंक रोड, मुलताई ।",
    "invocation": "॥ श्री गणेशाय नमः ॥",
    "gstin": "23ACLPV6913C1ZL",
    "mobiles": ["9425635130", "8871984442"],
    "bis": "7490219418",
    "bank": "State Bank of India",
    "account": "32191570144",
    "ifsc": "SBIN0030238",
    "note": "नोट - बिल की रकम १५ दिन के अंदर नही आने पर २ रु. प्रति सैकड़ा ब्याज लगेगा ।",
}


def _asset_data_uri(name):
    fp = os.path.join(HERE, "assets", name)
    if not os.path.exists(fp):
        return ""
    import base64
    with open(fp, "rb") as f:
        return "data:image/svg+xml;base64," + base64.b64encode(f.read()).decode()


def shop_print():
    return {**SHOP_PRINT, **(CFG.get("shop_print") or {})}


PRINT_CSS = """
@page { size: A5 portrait; margin: 8mm 9mm 10mm; }
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; }
body { font: 10.5pt/1.35 "Nirmala UI", "Segoe UI", system-ui, sans-serif; color: #1d1b18; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
:root { --m: #8e1b1b; --r: #c0392b; --soft: #fbf3ea; --line: #e5cdb8; }
.sheet { width: 130mm; margin: 0 auto; position: relative; }
.top { display: grid; grid-template-columns: 1fr auto 1fr; align-items: start; font-size: 8pt; font-weight: 700; color: #3b2a22; }
.top .inv { text-align: center; }
.top .inv { color: var(--r); font-weight: 600; font-size: 7.5pt; }
.top .mob { text-align: right; }
.brand { display: grid; grid-template-columns: 20mm 1fr 20mm; align-items: center; gap: 2mm; margin-top: 1mm; }
.brand .logo { width: 20mm; height: auto; display: block; }
.vj { width: 15mm; height: 15mm; border: 1.2pt solid var(--m); border-radius: 50%; display: grid; place-items: center; font: 700 15pt/1 Georgia, "Times New Roman", serif; color: var(--m); letter-spacing: -1pt; }
.brand .mid { text-align: center; }
.brand .nm { font: 700 25pt/1.05 "Nirmala UI", sans-serif; color: var(--m); letter-spacing: .3pt; }
.brand .tag { display: inline-block; margin-top: 1mm; background: var(--r); color: #fff; font-size: 8.6pt; font-weight: 600; padding: .6mm 3mm; border-radius: 1mm; }
.brand .addr { font-size: 8.4pt; font-weight: 600; margin-top: 1mm; }
.bis { text-align: center; font-size: 6.8pt; font-weight: 700; color: #2d2a6e; line-height: 1.2; }
.bis img { display: block; width: 19mm; height: auto; margin: 0 auto .5mm; }
.bis span { display: block; font-size: 8pt; letter-spacing: .5pt; }
.rule { height: 0; border-top: 1pt solid var(--m); margin: 2mm 0 2.5mm; }
.doctitle { text-align: center; margin: -1mm 0 1.5mm; }
.doctitle span { font-size: 8pt; font-weight: 700; letter-spacing: 2pt; color: var(--m); border: .8pt solid var(--m); border-radius: 3mm; padding: .3mm 4mm; }
.fl { display: flex; gap: 4mm; align-items: baseline; margin: 1.6mm 0; font-size: 10pt; }
.fl .k { font-weight: 700; white-space: nowrap; }
.fl .v { flex: 1; border-bottom: .6pt dotted #9c8b7c; padding: 0 1mm .3mm; min-height: 5mm; font-weight: 600; }
.fl .no { font: 700 15pt/1 Georgia, serif; color: var(--r); }
.fl .grow { flex: 1; }
table.lines { width: 100%; border-collapse: separate; border-spacing: 0; margin-top: 3mm; font-size: 9.8pt; }
table.lines thead { display: table-header-group; }
table.lines th { background: var(--r); color: #fff; font-weight: 700; padding: 1.4mm 1.5mm; font-size: 9pt; border-left: 1.2pt solid #fff; }
table.lines th:first-child { border-left: 0; border-radius: 1.5mm 0 0 1.5mm; text-align: left; }
table.lines th:last-child { border-radius: 0 1.5mm 1.5mm 0; }
table.lines td { padding: 1.7mm 1.5mm; border-bottom: .5pt solid var(--line); vertical-align: top; }
table.lines tr { break-inside: avoid; }
table.lines.compact td { padding: 1.1mm 1.5mm; font-size: 9.3pt; }
table.lines td.c, table.lines th.c { text-align: center; }
table.lines .sub { display: block; font-size: 7.6pt; color: #7a6a5c; font-weight: 400; }
table.lines .mt { font-size: 7pt; color: var(--m); border: .5pt solid var(--line); border-radius: 1mm; padding: 0 1mm; margin-left: 1mm; }
table.lines th .cont { font-weight: 400; opacity: .8; }
.r { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
.sums { break-inside: avoid; margin-top: 2mm; margin-left: auto; width: 72mm; font-size: 10pt; }
.sums div { display: flex; justify-content: space-between; padding: 1mm 1.5mm; }
.sums .tot { border-top: 1.2pt solid #1d1b18; font-weight: 700; font-size: 12pt; }
.sums .paid { color: #1f5f3a; }
.sums .paid small { color: #7a6a5c; font-size: 8pt; }
.sums .due { background: var(--soft); border-top: .8pt solid var(--m); font-weight: 700; font-size: 13pt; color: var(--m); border-radius: 0 0 1.5mm 1.5mm; }
.words { font-size: 8.6pt; font-style: italic; color: #3d3831; margin-top: 1.5mm; break-inside: avoid; }
.acct { font-size: 8.2pt; color: #5c564d; margin-top: 1mm; }
.foot { break-inside: avoid; margin-top: 5mm; }
.bank { font-size: 8.2pt; font-weight: 700; color: var(--m); display: flex; justify-content: space-between; gap: 3mm; border-top: .8pt solid var(--m); padding-top: 1.5mm; }
.terms { font-size: 8pt; font-weight: 600; margin-top: 1mm; }
.sign { display: flex; justify-content: space-between; margin-top: 13mm; font-size: 9pt; font-weight: 700; }
.sign div { width: 42mm; text-align: center; border-top: .6pt solid #9c958a; padding-top: 1mm; }
.copy { position: absolute; top: -5mm; left: 0; right: 0; text-align: center; font-size: 6.5pt; color: #b3ab9e; }
.recline { font-size: 9.6pt; margin-top: 3mm; padding: 2.5mm 3mm; border: .6pt solid var(--line); border-radius: 1.5mm; background: var(--soft); }
@media screen { body { background: #ece8e1; } .sheet { background: #fff; padding: 9mm; margin: 8mm auto; width: 148mm; min-height: 210mm; box-shadow: 0 2px 14px rgba(0,0,0,.12); } .copy { top: 2mm; } }
"""


def _print_head(sp, title):
    mobs = "<br>".join(esc(m) for m in sp.get("mobiles") or [])
    vj, bis = _asset_data_uri("vj_logo.svg"), _asset_data_uri("bis_logo.svg")
    return f"""<div class="top"><div>GSTIN : {esc(sp['gstin'])}</div><div class="inv">{esc(sp['invocation'])}</div><div class="mob">M.: {mobs}</div></div>
<div class="brand">{f'<img class="logo" src="{vj}" alt="VJ">' if vj else '<div class="vj">VJ</div>'}
<div class="mid"><div class="nm">{esc(sp['name_hi'])}</div><div class="tag">{esc(sp['tagline'])}</div><div class="addr">{esc(sp['address'])}</div></div>
<div class="bis">{f'<img src="{bis}" alt="BIS">' if bis else ''}<span>{esc(sp.get('bis') or '')}</span></div></div>
<div class="rule"></div><div class="doctitle"><span>{title}</span></div>"""


def _party_lines(no, date, party, pc, no_label="क्र."):
    loc = ", ".join(pc.get("address") or [])
    return f"""<div class="fl"><span class="k">{no_label}</span><span class="no">{esc(no or '—')}</span><span class="grow"></span><span class="k">दिनांक :</span><span class="v" style="flex:0 0 34mm;text-align:center">{esc(date)}</span></div>
<div class="fl"><span class="k">श्री/श्रीमती</span><span class="v">{esc(party)}</span></div>
<div class="fl"><span class="k">पता</span><span class="v">{esc(loc)}</span><span class="k">मो.नं.</span><span class="v" style="flex:0 0 32mm">{esc(pc.get('mobile') or '')}</span></div>"""


def _print_foot(sp):
    return f"""<div class="foot"><div class="bank"><span>Bank Name : {esc(sp['bank'])}</span><span>A/C No.: {esc(sp['account'])}</span><span>IFSC Code : {esc(sp['ifsc'])}</span></div>
<div class="terms">{esc(sp['note'])}</div>
<div class="sign"><div>हस्ताक्षर खरीददार</div><div>हस्ताक्षर बेचनेवाला</div></div></div>"""


def _num(x, nd=2):
    try:
        x = float(x)
    except (TypeError, ValueError):
        return ""
    t = f"{x:.{nd}f}"
    return t.rstrip("0").rstrip(".") if "." in t else t


def render_doc(kind, master_id, date_iso=""):
    v = get_voucher(master_id, date_iso)
    if not v:
        return None, "This entry was not found in Tally."
    sp = shop_print()
    pc = party_contact(v["party"])
    ex = _log_extra(master_id)
    c = ex.get("contact") or {}
    if c.get("location"):
        pc["address"] = [c["location"]]
    if c.get("mobile"):
        pc["mobile"] = c["mobile"]
    d = v["date"]
    printed_on = dt.datetime.now().strftime("%d-%m-%Y %H:%M")
    page_css = ""
    if kind == "bill":
        item = ex.get("item") or (v["bill_ref"] if v["bill_ref"] and v["bill_ref"] != v["number"] else "Jewellery")
        lines = ex.get("items") or []
        if not lines or abs(sum(l["amount"] for l in lines) - v["amount"]) >= 0.5:   # Tally changed since: trust Tally
            lines = [{"item": item, "amount": v["amount"]}]
        tag = {"gold": "सोना", "silver": "चाँदी"}

        def _row(l):
            name = l["item"]
            k = re.match(r"^\s*(\d{2})\s*(?:k|kt|ct|carat|karat)\b\.?\s*(.*)$", name, re.I)
            if k and (l.get("metal") in (None, "", "gold")):
                name = k.group(2) or name
                mt = f'<span class="mt">सोना {k.group(1)}K</span>'
            else:
                mt = f'<span class="mt">{tag[l["metal"]]}</span>' if l.get("metal") in tag else ""
            return (f'<tr><td>{esc(name)}{mt}</td><td class="c">{_num(l.get("weight"), 3)}</td>'
                    f'<td class="c">{_num(l.get("rate"))}</td><td class="c">{_num(l.get("tax"), 0) if l.get("tax") else ""}</td>'
                    f'<td class="r">{_inr(l["amount"])}</td></tr>')
        rows = "".join(_row(l) for l in lines)
        pays = bill_payments(v["number"], v["party"])
        discs = bill_payments(v["number"], v["party"], "discount")
        paid = round(sum(x["amount"] for x in pays), 2)
        disc = round(sum(x["amount"] for x in discs), 2)
        due = round(v["amount"] - disc - paid, 2)
        mtxt = {"cash": "नगद", "upi": "UPI", "bank": "बैंक"}
        sums = f'<div class="tot"><span>कुल रकम{f" ({len(lines)} आइटम)" if len(lines) > 1 else ""}</span><span>{_inr(v["amount"])}</span></div>'
        if disc:
            sums += f'<div class="paid"><span>छूट / राउंड ऑफ</span><span>− {_inr(disc)}</span></div>'
            sums += f'<div class="tot" style="font-size:11pt"><span>देय रकम</span><span>{_inr(v["amount"] - disc)}</span></div>'
        for x in pays:
            sums += f'<div class="paid"><span>जमा <small>रसीद {esc(x["receipt_no"])} · {mtxt.get(x["mode"], x["mode"])} · {esc(x["date"])}</small></span><span>− {_inr(x["amount"])}</span></div>'
        if pays or disc:
            sums += f'<div class="due"><span>{"बाकी" if due >= -0.5 else "ज़्यादा जमा"}</span><span>{_inr(abs(due)) if abs(due) > 0.5 else "✓ पूरा"}</span></div>'
        acct = f'<div class="acct">खाते में कुल बाकी (आज तक) : {_inr(pc["balance"])}</div>' if pc.get("balance_side") == "Dr" and pc.get("balance") else ""
        un = user_note(v.get("narration_full", v.get("narration", "")))
        note = f'<div class="acct">नोट : {esc(un)}</div>' if un and "(voice entry)" not in un else ""
        page_css = f'@page {{ @bottom-center {{ content: "बिल {v["number"]} · पेज " counter(page) " / " counter(pages); font: 7pt "Nirmala UI", sans-serif; color: #9c958a; }} }}'
        body = f"""{_print_head(sp, "बिल · TAX INVOICE")}{_party_lines(v['number'], d, v['party'], pc)}
<table class="lines{' compact' if len(lines) > 10 else ''}"><thead><tr><th>विवरण <span class="cont">· बिल {esc(v['number'])}</span></th><th class="c" style="width:17mm">वजन</th><th class="c" style="width:16mm">दर</th><th class="c" style="width:15mm">टैक्स</th><th class="r" style="width:25mm">रकम</th></tr></thead>
<tbody>{rows}</tbody></table>
<div class="sums">{sums}</div>
<div class="words">{rupees_in_words(v['amount'] - disc)}</div>{acct}{note}
{_print_foot(sp)}"""
        title = f"Bill {v['number']}"
    else:
        mode = (ex.get("mode") or "cash").lower()
        mode_txt = {"cash": "नगद", "upi": "UPI", "bank": "बैंक / चेक"}.get(mode, mode)
        against = ex.get("bill_no") or (v["bill_ref"] if v.get("bill_type") == "Agst Ref" else "")
        bal = f'<div class="acct">खाते में बाकी (आज तक) : {_inr(pc["balance"])}</div>' if pc.get("balance_side") == "Dr" and pc.get("balance") else ""
        body = f"""{_print_head(sp, "रसीद · RECEIPT")}{_party_lines(v['number'] or v['reference'], d, v['party'], pc, "रसीद क्र.")}
<table class="lines"><thead><tr><th>विवरण</th><th class="c" style="width:22mm">माध्यम</th><th class="r" style="width:28mm">रकम</th></tr></thead>
<tbody><tr><td>खाते में जमा{(' · बिल क्र. ' + esc(against)) if against else ''}</td><td class="c">{mode_txt}</td><td class="r">{_inr(v['amount'])}</td></tr></tbody></table>
<div class="sums"><div class="tot"><span>प्राप्त रकम</span><span>{_inr(v['amount'])}</span></div></div>
<div class="words">{rupees_in_words(v['amount'])}</div>{bal}
<div class="recline">नगद/चेक/ड्राफ्ट हमारे लेने पेटे दिये सो आपके खाते में जमा किये।</div>
{_print_foot(sp)}"""
        title = f"Receipt {v['number']}"
    doc = f"""<!doctype html><html lang="hi"><head><meta charset="utf-8"><title>{esc(title)}</title><style>{PRINT_CSS}{page_css}</style></head>
<body><div class="sheet"><div class="copy">Printed {printed_on}</div>{body}</div></body></html>"""
    os.makedirs(PRINT_DIR, exist_ok=True)
    safe = re.sub(r"[^0-9A-Za-z_-]+", "_", f"{kind}-{v['number'] or master_id}-{v['date_iso']}")
    with open(os.path.join(PRINT_DIR, safe + ".html"), "w", encoding="utf-8") as f:
        f.write(doc)
    return doc, None


def list_printed(kind=""):
    out = []
    if os.path.isdir(PRINT_DIR):
        for fn in sorted(os.listdir(PRINT_DIR), reverse=True):
            if fn.endswith(".html") and (not kind or fn.startswith(kind + "-")):
                out.append({"file": fn, "at": dt.datetime.fromtimestamp(os.path.getmtime(os.path.join(PRINT_DIR, fn))).isoformat(timespec="minutes")})
    return out[:500]


# ================================================================ BILLS (Sales New)

def check_bill_no(bill_no, exclude_master_id=""):
    r = find_vouchers(bill_no)
    if not r.get("ok"):
        return r
    st = CFG["sales_voucher_type"].lower()
    m = [v for v in r["vouchers"] if v["type"].lower() == st and v["number"] == str(bill_no).strip()
         and str(v.get("master_id")) != str(exclude_master_id or "")]
    return {"ok": True, "bill_no": bill_no, "already_in_tally": bool(m), "matches": m}


def _clean_bill(p):
    if p.get("items"):
        try:
            p = {**p, "amount": round(sum(float(str(i.get("amount") or 0).replace(",", "")) for i in p["items"]), 2)}
        except (TypeError, ValueError):
            pass
    f = {
        "party": (p.get("party_ledger") or "").strip(),
        "bill_no": str(p.get("bill_no") or "").strip(),
        "item": " ".join(str(p.get("item") or "").split()),
        "note": (p.get("narration") or "").strip(),
    }
    try:
        f["amount"] = round(float(str(p.get("amount", "")).replace(",", "")), 2)
    except ValueError:
        return None, "amount is not a number"
    if f["amount"] <= 0:
        return None, "amount must be more than 0"
    try:
        f["date"] = parse_date(p.get("date"))
    except ValueError as e:
        return None, str(e)
    if not f["party"]:
        return None, "party_ledger missing"
    if not ledger_exists(f["party"]):
        return None, f"party_not_found: no ledger named '{f['party']}'"
    # item-by-item: each line has its own name + amount; Tally gets the joined names and the total
    lines = []
    for it in (p.get("items") or []):
        name = " ".join(str(it.get("item") or "").split())
        try:
            a = round(float(str(it.get("amount", "")).replace(",", "")), 2)
        except ValueError:
            return None, f"amount for '{name or 'item'}' is not a number"
        if not name and not a:
            continue
        if not name or a <= 0:
            return None, "every item needs a name and an amount"
        line = {"item": name, "amount": a}
        m = str(it.get("metal") or "").lower()
        if m in ("gold", "silver", "other"):
            line["metal"] = m
        for k in ("weight", "rate", "making_pct", "tax_pct", "metal_value", "making", "tax"):
            try:
                if it.get(k) not in (None, ""):
                    line[k] = round(float(it[k]), 3)
            except (TypeError, ValueError):
                pass
        lines.append(line)
    if lines:
        f["items"] = lines
        # Tally bill-reference name: all item names, but kept short when there are many
        names = [l["item"] for l in lines]
        ref = ", ".join(names)
        k = len(names)
        while len(ref) > 60 and k > 1:
            k -= 1
            ref = ", ".join(names[:k]) + f" +{len(names) - k}"
        f["item"] = ref
        f["amount"] = round(sum(l["amount"] for l in lines), 2)
    else:
        f["items"] = [{"item": f["item"] or f["bill_no"] or "Bill", "amount": f["amount"]}] if f["amount"] > 0 else []
    if not f["item"]:
        f["item"] = f["bill_no"] or "Bill"
    c = p.get("contact") or {}
    f["contact"] = {"mobile": _clean_mobile(c.get("mobile", "")), "location": " ".join(str(c.get("location") or "").split())}
    return f, None


ITEMS_MARK = "Items:"


def user_note(narr):
    """The staff's own note from a bill narration (the item details we add are dropped)."""
    narr = narr or ""
    if ITEMS_MARK not in narr:
        return narr.strip()
    return re.sub(r"^\s*Note:\s*", "", narr.split(ITEMS_MARK)[0]).strip()


def _f2(x):
    return f"{float(x):.2f}"


def bill_details(f):
    """Every item with weight, rate, metal value, making and tax, as it goes into Tally's narration."""
    rows, wsum = [], {}
    for i, it in enumerate(f.get("items") or [], 1):
        name, amt = it.get("item") or "Item", it.get("amount") or 0
        w, r = it.get("weight"), it.get("rate")
        if it.get("metal") in ("gold", "silver") and w and r:
            mv = it.get("metal_value") if it.get("metal_value") is not None else w * r
            mk_pct, tx_pct = it.get("making_pct") or 0, it.get("tax_pct") or 0
            mk = it.get("making") if it.get("making") is not None else mv * mk_pct / 100
            tx = it.get("tax") if it.get("tax") is not None else (mv + mk) * tx_pct / 100
            metal = "Gold" if it["metal"] == "gold" else "Silver"
            wsum[metal] = wsum.get(metal, 0) + w
            rows.append(f"{i}) {metal} {name} | Wt {w:.3f} g | Rate {r:g}/g | Value {_f2(mv)} | Making {mk_pct:g}% {_f2(mk)}"
                        f" | Tax {tx_pct:g}% {_f2(tx)} | Amount {_f2(amt)}")
        else:
            label = "Other " if it.get("metal") == "other" else ""
            rows.append(f"{i}) {label}{name} | Amount {_f2(amt)}")
    if not rows:
        return ""
    tot = ", ".join(f"{k} {v:.3f} g" for k, v in wsum.items())
    return ITEMS_MARK + "\n" + "\n".join(rows) + f"\nTotal{' ' + tot if tot else ''} | Bill amount {_f2(f['amount'])}"


def _bill_narration(f):
    if f.get("raw_narration") is not None:
        return f["raw_narration"]
    det = bill_details(f) if (f.get("items") and any(i.get("weight") or i.get("metal") for i in f["items"])) else ""
    note = (f.get("note") or "").strip()
    if not det:
        return note
    return (f"Note: {note}\n" if note else "") + det


def _xml_text(s):
    return esc(s).replace("\r\n", "\n").replace("\n", "&#13;&#10;")


def _bill_xml(f, vtype=None, sales_ledger=None):
    vtype = vtype or CFG["sales_voucher_type"]
    sl = sales_ledger or CFG["sales_ledger"]
    a = f"{f['amount']:.2f}"
    d = f["date"]
    num = f"\n<VOUCHERNUMBER>{esc(f['bill_no'])}</VOUCHERNUMBER>" if f["bill_no"] else ""
    narr = _bill_narration(f)
    nar = f"\n<NARRATION>{_xml_text(narr)}</NARRATION>" if narr else ""
    sales_alloc = f"\n<BILLALLOCATIONS.LIST><NAME>{esc(f['bill_no'])}</NAME><BILLTYPE>New Ref</BILLTYPE><AMOUNT>{a}</AMOUNT></BILLALLOCATIONS.LIST>" if f["bill_no"] else ""
    return f"""<VOUCHER VCHTYPE="{esc(vtype)}" ACTION="Create" OBJVIEW="Accounting Voucher View">
<DATE>{d:%Y%m%d}</DATE>
<EFFECTIVEDATE>{d:%Y%m%d}</EFFECTIVEDATE>
<VOUCHERTYPENAME>{esc(vtype)}</VOUCHERTYPENAME>{num}{nar}
<PARTYLEDGERNAME>{esc(f['party'])}</PARTYLEDGERNAME>
<PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW>
<ALLLEDGERENTRIES.LIST>
<LEDGERNAME>{esc(f['party'])}</LEDGERNAME>
<ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
<ISPARTYLEDGER>Yes</ISPARTYLEDGER>
<AMOUNT>-{a}</AMOUNT>
<BILLALLOCATIONS.LIST><NAME>{esc(f['item'])}</NAME><BILLTYPE>New Ref</BILLTYPE><AMOUNT>-{a}</AMOUNT></BILLALLOCATIONS.LIST>
</ALLLEDGERENTRIES.LIST>
<ALLLEDGERENTRIES.LIST>
<LEDGERNAME>{esc(sl)}</LEDGERNAME>
<ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
<AMOUNT>{a}</AMOUNT>{sales_alloc}
</ALLLEDGERENTRIES.LIST>
</VOUCHER>"""


# ---------------------------------------------------------------- item invoice (stock items in Particulars)
_stock_cache = {"at": 0.0, "items": {}}


def fetch_stock_items(force=False):
    """{lower-case name: {"name", "parent"}} for every stock item in Tally."""
    now = time.time()
    if not force and _stock_cache["at"] and now - _stock_cache["at"] < CFG["ledger_cache_seconds"]:
        return _stock_cache["items"]
    body = f"""<ENVELOPE>
<HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>VoiceBridgeStock</ID></HEADER>
<BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>{company_vars()}</STATICVARIABLES>
<TDL><TDLMESSAGE><COLLECTION NAME="VoiceBridgeStock" ISMODIFY="No"><TYPE>StockItem</TYPE><FETCH>Name,Parent</FETCH></COLLECTION></TDLMESSAGE></TDL>
</DESC></BODY></ENVELOPE>"""
    items = {}
    for m in re.finditer(r'<STOCKITEM NAME="([^"]+)"[^>]*>(.*?)</STOCKITEM>', tally_post(body, timeout=30), re.S):
        name = html.unescape(m.group(1))
        parent = html.unescape((re.search(r"<PARENT[^>]*>([^<]*)</PARENT>", m.group(2)) or [None, ""])[1]).strip()
        items[name.lower()] = {"name": name, "parent": parent}
    _stock_cache.update(at=now, items=items)
    return items


def _title(s):
    return " ".join(w[:1].upper() + w[1:] for w in str(s).split())


def stock_name_for(line):
    """Which Tally stock item a bill line goes on. Gold: 'Gold Chain 22K' (like the shop's 'Gold Ring 22K');
    silver: the plain name if the shop has it ('Bichhia'), else 'Silver <name>'; other: the name."""
    have = fetch_stock_items()
    metal = line.get("metal") or "other"
    m = re.match(r"^\s*(\d{2})\s*k\b\s*(.*)$", line.get("item") or "", re.I)
    kt, base = (m.group(1) + "K", m.group(2)) if m else ("", line.get("item") or "")
    base = _title(base.strip()) or ("Gold" if metal == "gold" else "Silver" if metal == "silver" else "Item")
    if metal == "gold":
        cands = [f"Gold {base} {kt}".strip(), f"{base} {kt}".strip() if kt else None, f"Gold {base}" if not kt else None,
                 base if not kt else None]
        group = "Gold"
    elif metal == "silver":
        cands = [base, f"Silver {base}", f"{base} Silver"]
        group = "Silver"
    else:
        cands, group = [base], ""
    for c in [c for c in cands if c]:
        hit = have.get(c.lower())
        if hit and (not group or hit["parent"].lower() == group.lower() or metal == "other"):
            return hit["name"], group, False
    new = cands[0]
    if new.lower() in have:                      # name taken by another group's item
        new = f"{'Silver' if metal == 'silver' else 'Gold' if metal == 'gold' else 'Item'} {base} {kt}".strip()
    return new, group, True


def ensure_stock_item(name, group):
    have = fetch_stock_items()
    if name.lower() in have:
        return True
    parent = f"<PARENT>{esc(group)}</PARENT>" if group and group.lower() in {v["name"].lower() for v in have.values()} | {"gold", "silver"} else ""
    inner = (f'<STOCKITEM NAME="{esc(name)}" ACTION="Create"><NAME.LIST><NAME>{esc(name)}</NAME></NAME.LIST>'
             f'{parent}<BASEUNITS>{esc(CFG["stock_unit"])}</BASEUNITS></STOCKITEM>')
    r = import_xml("All Masters", inner)
    ok = r["created"] >= 1 or r["altered"] >= 1
    applog("STOCK", "OK" if ok else "FAIL", f"create {name} under {group or 'Primary'}: {r}")
    if ok:
        have[name.lower()] = {"name": name, "parent": group}
    return ok


def _invoice_xml(f, vtype=None, sales_ledger=None):
    """Sales as an item invoice: each item is a stock line (weight in gm, rate, amount incl. making + tax),
    all going to the same sales ledger as before, so the accounts don't change."""
    vtype = vtype or CFG["sales_voucher_type"]
    sl = sales_ledger or CFG["sales_ledger"]
    unit, gdn = CFG["stock_unit"], CFG["stock_godown"]
    a = f"{f['amount']:.2f}"
    d = f["date"]
    num = f"\n<VOUCHERNUMBER>{esc(f['bill_no'])}</VOUCHERNUMBER>" if f["bill_no"] else ""
    narr = _bill_narration(f)
    nar = f"\n<NARRATION>{_xml_text(narr)}</NARRATION>" if narr else ""
    inv = []
    for it in f["items"]:
        amt = f"{it['amount']:.2f}"
        w = it.get("weight") if it.get("metal") in ("gold", "silver") else None
        r = it.get("rate") if w else None
        qty = f"\n<ACTUALQTY> {w:.3f} {unit}</ACTUALQTY>\n<BILLEDQTY> {w:.3f} {unit}</BILLEDQTY>" if w else ""
        rate = f"\n<RATE>{r:g}/{unit}</RATE>" if w and r else ""
        inv.append(f"""<ALLINVENTORYENTRIES.LIST>
<STOCKITEMNAME>{esc(it['stock_item'])}</STOCKITEMNAME>
<ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>{rate}
<AMOUNT>{amt}</AMOUNT>{qty}
<BATCHALLOCATIONS.LIST><GODOWNNAME>{esc(gdn)}</GODOWNNAME><BATCHNAME>Primary Batch</BATCHNAME><AMOUNT>{amt}</AMOUNT>{qty}</BATCHALLOCATIONS.LIST>
<ACCOUNTINGALLOCATIONS.LIST><LEDGERNAME>{esc(sl)}</LEDGERNAME><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><AMOUNT>{amt}</AMOUNT></ACCOUNTINGALLOCATIONS.LIST>
</ALLINVENTORYENTRIES.LIST>""")
    return f"""<VOUCHER VCHTYPE="{esc(vtype)}" ACTION="Create" OBJVIEW="Invoice Voucher View">
<DATE>{d:%Y%m%d}</DATE>
<EFFECTIVEDATE>{d:%Y%m%d}</EFFECTIVEDATE>
<VOUCHERTYPENAME>{esc(vtype)}</VOUCHERTYPENAME>{num}{nar}
<PARTYLEDGERNAME>{esc(f['party'])}</PARTYLEDGERNAME>
<BASICBUYERNAME>{esc(f['party'])}</BASICBUYERNAME>
<PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW>
<ISINVOICE>Yes</ISINVOICE>
<LEDGERENTRIES.LIST>
<LEDGERNAME>{esc(f['party'])}</LEDGERNAME>
<ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
<ISPARTYLEDGER>Yes</ISPARTYLEDGER>
<AMOUNT>-{a}</AMOUNT>
<BILLALLOCATIONS.LIST><NAME>{esc(f['item'])}</NAME><BILLTYPE>New Ref</BILLTYPE><AMOUNT>-{a}</AMOUNT></BILLALLOCATIONS.LIST>
</LEDGERENTRIES.LIST>
{chr(10).join(inv)}
</VOUCHER>"""


def _post_bill(f, vtype=None, sales_ledger=None):
    """Item invoice when possible; if Tally refuses it (stock off, unit missing…), the old one-line bill."""
    items = f.get("items") or []
    if CFG.get("bill_items_in_tally") and items and all(i.get("item") for i in items):
        try:
            prepared = []
            for it in items:
                name, group, _new = stock_name_for(it)
                if not ensure_stock_item(name, group):
                    raise RuntimeError(f"could not create stock item {name}")
                prepared.append({**it, "stock_item": name})
            fi = {**f, "items": prepared}
            res = import_xml("Vouchers", _invoice_xml(fi, vtype, sales_ledger))
            if res["created"] >= 1 and res["errors"] == 0 and res["exceptions"] == 0:
                res["mode"] = "invoice"
                return res
            applog("BILL", "FAIL", f"invoice refused, using one-line bill: {res}")
            if res.get("exceptions") and not res.get("line_errors"):
                return res                       # e.g. duplicate number: the plain bill would fail the same way
        except Exception as e:
            applog("BILL", "FAIL", f"invoice error, using one-line bill: {e}")
    res = import_xml("Vouchers", _bill_xml(f, vtype, sales_ledger))
    res["mode"] = "accounting"
    return res


def _bill_log(f, ok, res, action="create", replaces="", master_id=""):
    return {
        "kind": "bill", "ok": ok, "action": action, "posted_at": dt.datetime.now().isoformat(timespec="seconds"),
        "receipt_no": f["bill_no"], "bill_no": f["bill_no"], "item": f["item"], "items": f.get("items") or [], "party_ledger": f["party"],
        "contact": f.get("contact") or {},
        "amount": f["amount"], "date": f["date"].isoformat(), "mode": "",
        "master_id": str(master_id or res.get("last_vch_id") or ""), "replaces": str(replaces or ""),
        "vtype": CFG["sales_voucher_type"], "tally": res,
    }


def create_bill(p):
    """Bill, then (optionally) save the customer's mobile/place and post the money paid now as a receipt."""
    out = _create_bill_only(p)
    if not out.get("ok"):
        return out
    c = p.get("contact") or {}
    if c.get("changed"):
        try:
            r = update_contact(p.get("party_ledger", ""), c.get("mobile", ""), c.get("location", ""))
            out["contact_saved"] = r.get("ok", False)
        except Exception as e:
            out["contact_saved"] = False
            applog("TALLY", "ERROR", f"contact update: {e}")
    # discount / round off: same way the shop does it in Tally - a Receipt voucher with "Discount A/c" against this bill
    try:
        disc = round(float(str(p.get("discount") or 0).replace(",", "")), 2)
    except ValueError:
        disc = 0
    if disc > 0:
        dr = create_discount(p, disc)
        out["discount"] = dr
        out["message"] += f" · छूट Rs {disc:.2f}" if dr.get("ok") else f" · ⚠ discount NOT entered: {dr.get('message') or dr.get('error')}"
    pay = p.get("payment") or {}
    try:
        paid = round(float(str(pay.get("amount") or 0).replace(",", "")), 2)
    except ValueError:
        paid = 0
    if paid > 0:
        rno = str(pay.get("receipt_no") or "").strip()
        if not rno:
            nx = next_receipt_no(force=True)
            rno = str((nx or {}).get("next") or "") if isinstance(nx, dict) else str(nx or "")
        rr = create_receipt({"receipt_no": rno, "bill_no": p.get("bill_no", ""), "party_ledger": p.get("party_ledger", ""),
                             "amount": paid, "date": p.get("date"), "mode": pay.get("mode") or "cash", "narration": ""})
        out["receipt"] = {"ok": rr.get("ok", False), "receipt_no": rno, "amount": paid,
                          "master_id": rr.get("tally_voucher_id"), "message": rr.get("message", "")}
        if rr.get("ok"):
            out["message"] += f" · Receipt {rno}: Rs {paid:.2f} received"
        else:
            out["message"] += f" · ⚠ receipt NOT entered: {rr.get('message') or rr.get('error')}"
    return out


def create_discount(p, amount):
    with _lock:
        try:
            date = parse_date(p.get("date"))
        except ValueError as e:
            return {"ok": False, "error": str(e)}
        bill_no = str(p.get("bill_no") or "").strip()
        f = {"party": (p.get("party_ledger") or "").strip(), "receipt_no": f"D{bill_no}" if bill_no else "",
             "mode": "discount", "note": "Discount / round off", "bill_no": bill_no, "amount": amount, "date": date,
             "contra": CFG.get("discount_ledger") or "Discount A/c"}
        if not ledger_exists(f["contra"]):
            return {"ok": False, "error": "no_discount_ledger", "message": f"'{f['contra']}' ledger not found in Tally"}
        xml, note = _voucher_xml(f, vtype=CFG.get("discount_voucher_type") or "Receipt")
        res = import_xml("Vouchers", xml)
        ok = res["created"] >= 1 and res["errors"] == 0 and res["exceptions"] == 0
        rec = _log_rec(f, ok, res, note)
        rec.update(kind="discount", vtype=CFG.get("discount_voucher_type") or "Receipt")
        log(rec)
        if not ok:
            applog("TALLY", "FAIL", f"discount {bill_no}: {res}")
        return {"ok": ok, "master_id": res.get("last_vch_id"), "amount": amount,
                **({} if ok else {"message": "; ".join(res["line_errors"]) or "Tally rejected the discount"})}


def set_bill_discount(p, amount):
    """Make this bill's discount equal to `amount` (0 removes it). Replaces an earlier discount made from this app."""
    bill_no, party = str(p.get("bill_no") or "").strip(), (p.get("party_ledger") or "").strip()
    old = bill_payments(bill_no, party, "discount")
    old_amt = round(sum(x["amount"] for x in old), 2)
    if abs(old_amt - amount) < 0.005:
        return {"ok": True, "unchanged": True, "amount": amount}
    for x in old:
        v = get_voucher(x["master_id"], x["date_iso"]) if x.get("master_id") else None
        if v:
            gone, _ = _delete_voucher(v)
            if not gone:
                return {"ok": False, "error": "delete_failed", "message": f"old discount D{bill_no} could not be removed in Tally"}
        log({"kind": "discount", "ok": True, "removed": True, "action": "remove", "posted_at": dt.datetime.now().isoformat(timespec="seconds"),
             "receipt_no": x["receipt_no"], "bill_no": bill_no, "party_ledger": party, "amount": 0, "master_id": x.get("master_id")})
    if amount > 0:
        return create_discount(p, amount)
    return {"ok": True, "removed": True, "amount": 0}


def update_bill(p):
    out = _update_bill_only(p)
    if not out.get("ok"):
        return out
    c = p.get("contact") or {}
    if c.get("changed"):
        try:
            out["contact_saved"] = update_contact(p.get("party_ledger", ""), c.get("mobile", ""), c.get("location", "")).get("ok", False)
        except Exception as e:
            out["contact_saved"] = False
            applog("TALLY", "ERROR", f"contact update: {e}")
    if "discount" in p:
        try:
            disc = round(float(str(p.get("discount") or 0).replace(",", "")), 2)
        except ValueError:
            disc = 0
        dr = set_bill_discount(p, disc)
        out["discount"] = dr
        if not dr.get("unchanged"):
            if dr.get("ok"):
                out["message"] += f" · छूट Rs {disc:.2f}" if disc > 0 else " · छूट हटाई"
            else:
                out["message"] += f" · ⚠ discount NOT updated: {dr.get('message') or dr.get('error')}"
    return out


def _create_bill_only(p):
    with _lock:
        f, err = _clean_bill(p)
        if err:
            return {"ok": False, "error": err.split(":")[0], "message": err}
        if f["bill_no"] and not p.get("allow_duplicate"):
            tc = check_bill_no(f["bill_no"])
            if tc.get("already_in_tally"):
                m = tc["matches"][0]
                return {"ok": False, "error": "duplicate_bill",
                        "message": f"Bill {f['bill_no']} is already in Tally: {m['party']} Rs {m['amount']} on {m['date']}."}
        res = _post_bill(f)
        ok = res["created"] >= 1 and res["errors"] == 0 and res["exceptions"] == 0
        log(_bill_log(f, ok, res))
        if ok:
            return {"ok": True, "tally_voucher_id": res["last_vch_id"], "master_id": res["last_vch_id"],
                    "message": f"Bill {f['bill_no']} entered: {f['party']}, {f['item']}, Rs {f['amount']:.2f}, {f['date']:%d-%m-%Y}"}
        hint = " (often a duplicate bill number)" if res.get("exceptions") else ""
        return {"ok": False, "error": "tally_rejected", "message": ("; ".join(res["line_errors"]) or "Tally rejected the bill") + hint, "tally": res}


def load_bill(master_id="", date_iso="", bill_no=""):
    v = None
    if master_id:
        v = get_voucher(master_id, date_iso)
    elif bill_no:
        r = check_bill_no(bill_no)
        if r.get("ok") and r["matches"]:
            v = r["matches"][0]
    if not v:
        return {"ok": False, "error": "not_found", "message": "This bill was not found in Tally."}
    ex = _log_extra(v["master_id"])
    items = ex.get("items") if ex.get("items") and abs(sum(i["amount"] for i in ex["items"]) - v["amount"]) < 0.5 else []
    disc = round(sum(x["amount"] for x in bill_payments(v["number"], v["party"], "discount")), 2)
    return {"ok": True, "master_id": v["master_id"], "type": v["type"], "orig_date": v["date_iso"], "discount": disc,
            "draft": {"bill_no": v["number"], "item": v["bill_ref"] if v["bill_ref"] != v["number"] else "", "items": items,
                      "amount": f"{v['amount']:g}", "name": "", "ledger": v["party"], "date": v["date_iso"], "note": user_note(v.get("narration_full", v["narration"]))},
            "sales_ledger": v["contra"]}


def _restore_bill(old):
    try:
        f = {"party": old["party"], "bill_no": old["number"], "item": old.get("bill_ref") or old["number"] or "Bill",
             "note": old.get("narration", ""), "raw_narration": old.get("narration_full", old.get("narration", "")),
             "amount": old["amount"], "date": parse_date(old["date_iso"])}
        r = import_xml("Vouchers", _bill_xml(f, vtype=old["type"], sales_ledger=old.get("contra") or CFG["sales_ledger"]))
        return r["created"] >= 1 and r["errors"] == 0
    except Exception:
        return False


def _update_bill_only(p):
    mid = str(p.get("master_id") or "").strip()
    if not mid:
        return {"ok": False, "error": "master_id missing"}
    with _lock:
        old = get_voucher(mid, p.get("orig_date", ""))
        if not old or old.get("cancelled"):
            return {"ok": False, "error": "not_found", "message": "Original bill not found in Tally."}
        f, err = _clean_bill(p)
        if err:
            return {"ok": False, "error": err.split(":")[0], "message": err}
        if f["bill_no"] and not p.get("allow_duplicate"):
            tc = check_bill_no(f["bill_no"], exclude_master_id=mid)
            if tc.get("already_in_tally"):
                m = tc["matches"][0]
                return {"ok": False, "error": "duplicate_bill", "message": f"Bill {f['bill_no']} is already used: {m['party']} on {m['date']}."}
        gone, _ = _delete_voucher(old)
        if not gone:
            return {"ok": False, "error": "delete_failed", "message": f"Could not remove the old bill {old['number']}. Nothing was changed."}
        res = _post_bill(f)
        ok = res["created"] >= 1 and res["errors"] == 0 and res["exceptions"] == 0
        if not ok:
            restored = _restore_bill(old)
            log(_bill_log(f, False, res, action="edit", replaces=mid))
            return {"ok": False, "error": "tally_rejected", "restored_old": restored,
                    "message": "Tally did not accept the corrected bill. " + ("The old bill was put back." if restored else
                               f"IMPORTANT: old bill could not be put back: {old['number']}, {old['party']}, Rs {old['amount']}, {old['date']}.")}
        new_mid = str(res.get("last_vch_id") or "")
        log(_bill_log(f, True, res, action="edit", replaces=mid, master_id=new_mid))
        return {"ok": True, "master_id": new_mid,
                "message": f"Bill {f['bill_no']} corrected: {f['party']}, {f['item']}, Rs {f['amount']:.2f}, {f['date']:%d-%m-%Y}. Old entry replaced."}


def item_suggestions():
    return ["Chain", "Pendent", "Ring", "Tops", "Fpyl", "Long", "Kada", "Mangalsutra", "Jhale", "Bali", "Jodve", "Mni", "Bichhia", "Mukhda", "Dorla", "Ltkn"]


# ---------------------------------------------------------------- accounts tab: a customer's bills & receipts from Tally
def account_search(q):
    q = (q or "").strip()
    digits = re.sub(r"\D", "", q)
    if len(digits) >= 10:
        r = by_mobile(digits)
        return {"ok": True, "by": "mobile", "matches": [{"ledger": m["ledger"], "note": m.get("location", "")} for m in r.get("matches", [])]}
    r = find_party(q, limit=8)
    return {"ok": True, "by": "name", "matches": [{"ledger": c["ledger"], "note": ""} for c in r.get("candidates", [])]}


def _vkind(v):
    t = v["type"].lower()
    if "sale" in t or "invoice" in t or t == "pos":
        return "bill"
    if re.search(r"rec(e)?ipt", t):
        if (v.get("contra") or "").lower() == CFG.get("discount_ledger", "Discount A/c").lower() or re.match(r"^D\d", v.get("number") or ""):
            return "discount"
        return "receipt"
    if "credit note" in t or "return" in t:
        return "return"
    if "payment" in t:
        return "payment"
    if "journal" in t:
        return "journal"
    return "other"


def party_statement(ledger, years=None):
    if not ledger_exists(ledger):
        return {"ok": False, "error": "ledger_not_found", "message": f"'{ledger}' नाम का खाता Tally में नहीं मिला"}
    today = dt.date.today()
    yrs = int(years or CFG.get("lookup_years", 2))
    start_year = (today.year if today.month >= 4 else today.year - 1) - (yrs - 1)
    frm = dt.date(start_year, 4, 1)
    name = ledger.replace('"', "")
    # every voucher with a line on this ledger (bills, receipts, and the shop's own journals etc.)
    vs = query_vouchers("$$FilterCount:AllLedgerEntries:VBQL &gt; 0 OR $PartyLedgerName = \"" + esc(name) + "\"", frm,
                        today + dt.timedelta(days=1), timeout=120, party=ledger,
                        extra=f'<SYSTEM TYPE="Formulae" NAME="VBQL">$LedgerName = "{esc(name)}"</SYSTEM>')
    rows = []
    for v in vs:
        if v["cancelled"]:
            continue
        k = _vkind(v)
        dr = v["dr"] if v["dr"] is not None else (k == "bill")
        rows.append({"date": v["date"], "date_iso": v["date_iso"], "type": v["type"], "kind": k, "number": v["number"],
                     "ref": v["bill_ref"] if v["bill_ref"] != v["number"] else "", "amount": v["amount"], "dr": dr,
                     "narration": user_note(v.get("narration_full", v["narration"]))[:120],
                     "master_id": v["master_id"]})
    rows.sort(key=lambda r: (r["date_iso"], int(r["master_id"] or 0)), reverse=True)
    tot = lambda k: round(sum(r["amount"] for r in rows if r["kind"] == k), 2)
    info = party_info(ledger)
    return {"ok": True, "ledger": ledger, "from": frm.isoformat(), "to": today.isoformat(), "years": yrs, "info": info,
            "rows": rows, "totals": {"bills": tot("bill"), "receipts": tot("receipt"), "discounts": tot("discount"),
                                     "debit": round(sum(r["amount"] for r in rows if r["dr"]), 2),
                                     "credit": round(sum(r["amount"] for r in rows if not r["dr"]), 2)}}


# ---------------------------------------------------------------- history tab: every entry made from this PC (kept locally)
def history(limit=2000):
    out = []
    if os.path.exists(LOG_PATH):
        with open(LOG_PATH, encoding="utf-8") as f:
            lines = f.readlines()
        for line in reversed(lines):
            try:
                r = json.loads(line)
            except ValueError:
                continue
            t = r.get("tally") or {}
            err = r.get("error") or "; ".join(t.get("line_errors") or []) or ("" if r.get("ok") else "Tally ने मना किया")
            kind = r.get("kind") or "receipt"
            out.append({
                "at": r.get("posted_at", ""), "kind": kind, "action": "remove" if r.get("removed") else (r.get("action") or "create"),
                "ok": bool(r.get("ok")), "number": str(r.get("bill_no") if kind == "bill" else r.get("receipt_no") or ""),
                "bill_no": str(r.get("bill_no") or ""), "party": r.get("party_ledger", ""), "amount": r.get("amount", 0),
                "mode": r.get("mode", ""), "date": str(r.get("date") or "")[:10], "master_id": str(r.get("master_id") or t.get("last_vch_id") or ""),
                "items": [{"item": i.get("item"), "weight": i.get("weight"), "rate": i.get("rate"), "amount": i.get("amount")} for i in (r.get("items") or [])],
                "error": err[:200], "replaces": str(r.get("replaces") or "")})
            if len(out) >= limit:
                break
    return {"ok": True, "count": len(out), "rows": out}


def history_csv():
    import csv
    import io
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Posted at", "Type", "Action", "Status", "Number", "Bill no", "Customer", "Amount", "Mode", "Voucher date", "Items", "Error"])
    kinds = {"bill": "Bill", "receipt": "Receipt", "discount": "Discount"}
    for r in history(100000)["rows"]:
        items = "; ".join(f"{i['item']}" + (f" {i['weight']}g @{i['rate']}" if i.get("weight") else "") + f" = {i['amount']}" for i in r["items"])
        w.writerow([r["at"], kinds.get(r["kind"], r["kind"]), r["action"], "OK" if r["ok"] else "FAILED", r["number"], r["bill_no"],
                    r["party"], r["amount"], r["mode"], r["date"], items, r["error"]])
    return "\ufeff" + buf.getvalue()


def today_entries(kind="receipt"):
    today = dt.date.today().isoformat()
    rows = {}
    order = []
    if os.path.exists(LOG_PATH):
        with open(LOG_PATH, encoding="utf-8") as f:
            for line in f:
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                if not r.get("ok") or r.get("kind", "receipt") != kind:
                    continue
                mid = str(r.get("master_id") or r.get("tally", {}).get("last_vch_id") or "")
                rep = str(r.get("replaces") or "")
                if rep and rep in rows:
                    first = rows.pop(rep)["first_at"]
                    order = [m for m in order if m != rep]
                else:
                    first = r.get("posted_at", "")
                if not first.startswith(today) and not r.get("posted_at", "").startswith(today):
                    continue
                rows[mid] = {
                    "first_at": first, "time": r["posted_at"][11:16], "receipt_no": r.get("receipt_no", ""),
                    "party_ledger": r.get("party_ledger", ""), "amount": r.get("amount", 0), "mode": r.get("mode", ""),
                    "ok": True, "bill_no": r.get("bill_no", ""), "master_id": mid, "date": r.get("date", ""),
                    "vtype": r.get("vtype", "Receipt"), "edited": bool(rep), "item": r.get("item", ""),
                }
                if mid not in order:
                    order.append(mid)
    items = [rows[m] for m in reversed(order) if m in rows]
    return {"date": today, "count": len(items), "total": round(sum(float(i["amount"] or 0) for i in items), 2), "items": items}


# ---------------------------------------------------------------- HTTP

class Handler(BaseHTTPRequestHandler):
    server_version = "TallyVoiceBridge/1.0"

    def _send(self, code, obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _is_local(self):
        # Requests through the Cloudflare tunnel carry Cf-* headers; the UI is only for this PC.
        if any(h.lower().startswith("cf-") for h in self.headers.keys()):
            return False
        return self.client_address[0] in ("127.0.0.1", "::1")

    def _send_ui(self):
        path = os.path.join(HERE, "ui.html")
        with open(path, encoding="utf-8") as f:
            html_doc = f.read().replace("__TOKEN__", CFG["token"]).replace("__AGENT_ID__", CFG.get("agent_id", ""))
        data = html_doc.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _authed(self):
        tok = self.headers.get("X-Bridge-Token") or ""
        auth = self.headers.get("Authorization") or ""
        if auth.lower().startswith("bearer "):
            tok = tok or auth[7:]
        if CFG["token"] in ("", "CHANGE_ME") or tok != CFG["token"]:
            self._send(401, {"ok": False, "error": "unauthorized"})
            return False
        return True

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        return json.loads(self.rfile.read(n).decode("utf-8"))

    def _send_html(self, code, doc):
        data = doc.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path.startswith("/print?") or self.path == "/print":
            if not self._is_local():
                return self._send(404, {"ok": False, "error": "not found"})
            from urllib.parse import urlparse, parse_qs
            q = {k: v[0] for k, v in parse_qs(urlparse(self.path).query).items()}
            try:
                doc, err = render_doc(q.get("kind", "receipt"), q.get("mid", ""), q.get("date", ""))
            except Exception as e:
                doc, err = None, f"{type(e).__name__}: {e}"
            if err:
                return self._send_html(404, f"<meta charset=utf-8><body style='font-family:Segoe UI;padding:30px'>प्रिंट नहीं बना: {esc(err)}</body>")
            return self._send_html(200, doc)
        if self.path.startswith("/printed/"):
            if not self._is_local():
                return self._send(404, {"ok": False, "error": "not found"})
            from urllib.parse import unquote
            fn = os.path.basename(unquote(self.path[len("/printed/"):].split("?")[0]))
            fp = os.path.join(PRINT_DIR, fn)
            if not fn.endswith(".html") or not os.path.isfile(fp):
                return self._send_html(404, "<meta charset=utf-8><body style='font-family:Segoe UI;padding:30px'>यह प्रिंट नहीं मिला</body>")
            with open(fp, encoding="utf-8") as f:
                return self._send_html(200, f.read())
        if self.path in ("/", "/index.html", "/ui"):
            if not self._is_local():
                return self._send(404, {"ok": False, "error": "not found"})
            return self._send_ui()
        if not self._authed():
            return
        if self.path.startswith("/api/today"):
            if not self._is_local():
                return self._send(404, {"ok": False, "error": "not found"})
            return self._send(200, today_entries("bill" if "kind=bill" in self.path else "receipt"))
        if self.path.startswith("/api/history") and not self._is_local():
            return self._send(404, {"ok": False, "error": "not found"})
        if self.path.startswith("/api/history.csv"):
            data = history_csv().encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/csv; charset=utf-8")
            self.send_header("Content-Disposition", f'attachment; filename="tally-voice-history-{dt.date.today()}.csv"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if self.path.startswith("/api/history"):
            return self._send(200, history())
        if self.path.startswith("/api/usage"):
            return self._send(200, usage_summary())
        if self.path.startswith("/api/settings"):
            if not self._is_local():
                return self._send(404, {"ok": False, "error": "not found"})
            return self._send(200, settings_view())
        if self.path.startswith("/api/printed"):
            if not self._is_local():
                return self._send(404, {"ok": False, "error": "not found"})
            return self._send(200, {"files": list_printed("bill" if "kind=bill" in self.path else ("receipt" if "kind=receipt" in self.path else ""))})
        if self.path.startswith("/api/next_bill_no"):
            if not self._is_local():
                return self._send(404, {"ok": False, "error": "not found"})
            return self._send(200, {**next_bill_no(), "items": item_suggestions()})
        if self.path.startswith("/api/next_receipt_no"):
            if not self._is_local():
                return self._send(404, {"ok": False, "error": "not found"})
            return self._send(200, next_receipt_no())
        if self.path.startswith("/api/ledgers"):
            if not self._is_local():
                return self._send(404, {"ok": False, "error": "not found"})
            g = CFG["party_group"].lower()
            names = sorted(l["name"] for l in fetch_ledgers() if l["parent"].lower() == g)
            return self._send(200, {"names": names})
        if self.path.startswith("/health"):
            try:
                n = len(fetch_ledgers(force=True))
                self._send(200, {"ok": True, "tally": CFG["tally_url"], "company": CFG["company"] or "(open company)", "ledgers": n,
                                 "modes": [k for k, v in CFG["mode_ledgers"].items() if v],
                                 "version": app_version(), "update": dict(UPDATE_STATE)})
            except Exception as e:
                self._send(200, {"ok": False, "error": f"Tally not reachable: {e}", "version": app_version(), "update": dict(UPDATE_STATE)})
        else:
            self._send(404, {"ok": False, "error": "not found"})

    def do_POST(self):
        if not self._authed():
            return
        _last_activity["t"] = time.time()
        if self.path.startswith("/transcribe"):
            if not self._is_local():
                return self._send(404, {"ok": False, "error": "not found"})
            n = int(self.headers.get("Content-Length") or 0)
            audio = self.rfile.read(n) if n else b""
            try:
                return self._send(200, transcribe(audio, self.headers.get("Content-Type") or "audio/wav"))
            except Exception as e:
                applog("SCRIBE", "ERROR", f"{type(e).__name__}: {e}")
                return self._send(200, {"ok": False, "error": f"{type(e).__name__}: {e}"})
        try:
            p = self._body()
            if self.path.startswith("/find_party"):
                out = find_party(p.get("name", ""))
            elif self.path.startswith("/by_mobile"):
                out = by_mobile(p.get("mobile", ""))
            elif self.path.startswith("/account_search"):
                out = account_search(p.get("q", ""))
            elif self.path.startswith("/party_statement"):
                out = party_statement(p.get("ledger", ""), p.get("years"))
            elif self.path.startswith("/create_party"):
                out = create_party(p.get("name", ""), p.get("mobile", ""), p.get("location", ""))
            elif self.path.startswith("/create_receipt"):
                out = create_receipt(p)
            elif self.path.startswith("/party_info"):
                out = party_info(p.get("ledger", ""))
            elif self.path.startswith("/check_bill_no"):
                out = check_bill_no(p.get("bill_no", ""), p.get("exclude_master_id", ""))
            elif self.path.startswith("/parse"):
                out = parse_dictation(p.get("text", ""), p.get("tab", "receipt"), p.get("card"))
            elif self.path.startswith("/update_check"):
                if not self._is_local():
                    return self._send(404, {"ok": False, "error": "not found"})
                out = check_update(apply=bool(p.get("apply", True)))
            elif self.path.startswith("/onboarded"):
                if not self._is_local():
                    return self._send(404, {"ok": False, "error": "not found"})
                set_config(onboarded=bool(p.get("done", True)))
                out = {"ok": True}
            elif self.path.startswith("/settings"):
                if not self._is_local():
                    return self._send(404, {"ok": False, "error": "not found"})
                out = save_settings(p)
            elif self.path.startswith("/client_log"):
                applog("UI", str(p.get("level", "error")).upper(), str(p.get("msg", ""))[:1500])
                out = {"ok": True}
            elif self.path.startswith("/check_bill"):
                out = check_bill(p.get("bill_no", ""))
            elif self.path.startswith("/debug_vouchers"):
                out = debug_vouchers(p.get("number", ""), int(p.get("days", 3)))
            elif self.path.startswith("/check_receipt_no"):
                out = check_receipt_no(p.get("receipt_no", ""), p.get("exclude_master_id", ""))
            elif self.path.startswith("/load_receipt"):
                out = load_receipt(p.get("master_id", ""), p.get("date", ""), p.get("receipt_no", ""))
            elif self.path.startswith("/update_receipt"):
                out = update_receipt(p)
            elif self.path.startswith("/create_bill"):
                out = create_bill(p)
            elif self.path.startswith("/update_bill"):
                out = update_bill(p)
            elif self.path.startswith("/load_bill"):
                out = load_bill(p.get("master_id", ""), p.get("date", ""), p.get("bill_no", ""))
            else:
                return self._send(404, {"ok": False, "error": "not found"})
            if isinstance(out, dict) and out.get("ok") is False:
                applog("API", "FAIL", f"{self.path} {json.dumps(p, ensure_ascii=False)[:400]} -> {out.get('error')}: {str(out.get('message') or '')[:300]}")
            self._send(200, out)
        except urllib.error.URLError as e:
            applog("API", "ERROR", f"{self.path}: Tally not reachable ({e.reason})")
            self._send(200, {"ok": False, "error": f"Tally not reachable. Is TallyPrime open with port 9000 on? ({e.reason})"})
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            return
        except Exception as e:
            import traceback
            applog("API", "ERROR", f"{self.path} {json.dumps(p if 'p' in dir() else {}, ensure_ascii=False)[:400]}\n{traceback.format_exc()}")
            self._send(200, {"ok": False, "error": f"{type(e).__name__}: {e}"})

    def log_message(self, fmt, *args):
        if '" 200 ' in (fmt % args) and ("/api/today" in (fmt % args) or "/health" in (fmt % args)):
            return   # skip the every-20-seconds polling so the log stays readable
        line = "[%s] %s\n" % (dt.datetime.now().strftime("%H:%M:%S"), fmt % args)
        try:
            with open(os.path.join(HERE, "bridge.log"), "a", encoding="utf-8") as f:
                f.write(line)
        except OSError:
            pass


SAFE_JOBS = {
    "find_party": lambda a: find_party(a.get("name", "")),
    "party_info": lambda a: party_info(a.get("ledger", "")),
    "check_bill": lambda a: check_bill(a.get("bill_no", "")),
    "check_receipt_no": lambda a: check_receipt_no(a.get("receipt_no", "")),
    "load_receipt": lambda a: load_receipt(a.get("master_id", ""), a.get("date", ""), a.get("receipt_no", "")),
    "debug_vouchers": lambda a: debug_vouchers(a.get("number", ""), int(a.get("days", 3))),
    "health": lambda a: {"ok": True, "ledgers": len(fetch_ledgers(force=True))},
    "vch_stats": lambda a: vch_stats(a.get("days", 60), a.get("type", ""), int(a.get("n", 6))),
    "raw_export": lambda a: _raw_export(a.get("xml", ""), int(a.get("max", 6000))),
    "audio_devices": lambda a: _audio_devices(),
    "next_receipt_no": lambda a: next_receipt_no(force=True),
    "next_bill_no": lambda a: next_bill_no(force=True),
    "check_bill_no": lambda a: check_bill_no(a.get("bill_no", "")),
    "window_check": lambda a: _window_check(),
    "update_check": lambda a: check_update(apply=bool(a.get("apply", True))),
    "update_rollback": lambda a: rollback_update(),
    "window_start": lambda a: _window_start(),
    "window_stop": lambda a: _window_stop(),
    "window_procs": lambda a: _window_procs(),
    "window_start_gui": lambda a: (__import__("subprocess").Popen([_pyexe(True), os.path.join(HERE, "app_window.py")], cwd=HERE), {"ok": True})[1],
}


def _pyexe(gui=False):
    py = sys.executable
    base = os.path.dirname(py)
    return os.path.join(base, "pythonw.exe" if gui else "python.exe")


def _window_check():
    import subprocess
    code = "import sys,webview,clr;print(sys.version);print(webview.__version__ if hasattr(webview,'__version__') else 'webview ok')"
    r = subprocess.run([_pyexe(), "-c", code], capture_output=True, text=True, timeout=120, creationflags=0x08000000, cwd=HERE)
    return {"rc": r.returncode, "out": r.stdout[-1500:], "err": r.stderr[-3000:]}


def _window_procs():
    import subprocess
    ps = ("Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*app_window*' -or $_.Name -like 'Tally Voice*' } | "
          "Select-Object ProcessId,Name,CommandLine | ConvertTo-Json")
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=60, creationflags=0x08000000)
    return {"out": r.stdout[-3000:], "err": r.stderr[-500:]}


def _window_stop():
    """Close the Tally Voice desktop window process (only app_window.py, nothing else)."""
    import subprocess
    ps = ("Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*app_window.py*' } | "
          "ForEach-Object { Stop-Process -Id $_.ProcessId -Force; $_.ProcessId }")
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=60, creationflags=0x08000000)
    return {"stopped": r.stdout.split(), "err": r.stderr[-500:]}


def _window_start():
    """Start the desktop window with its errors captured to window_err.log."""
    import subprocess
    errf = open(os.path.join(HERE, "window_err.log"), "w", encoding="utf-8")
    subprocess.Popen([_pyexe(), os.path.join(HERE, "app_window.py")], stdout=errf, stderr=errf, cwd=HERE,
                     creationflags=0x08000000)
    return {"ok": True, "started": True}


def _audio_devices():
    # read-only: list sound devices Windows knows about
    import subprocess
    ps = ("Get-CimInstance Win32_PnPEntity | Where-Object { $_.PNPClass -eq 'AudioEndpoint' } | "
          "Select-Object Name,Status | ConvertTo-Json")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    out = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=40, creationflags=flags)
    try:
        return {"devices": json.loads(out.stdout or "[]")}
    except ValueError:
        return {"raw": out.stdout[-3000:], "err": out.stderr[-1000:]}


def _raw_export(xml, mx):
    # read-only: only Export requests are allowed through
    if "<TALLYREQUEST>Export</TALLYREQUEST>" not in xml or "Import" in xml:
        return {"error": "only export requests"}
    t = tally_post(xml, timeout=90)
    return {"len": len(t), "head": t[:mx]}


def ensure_window_lib():
    """One-time: install the small library that gives Tally Voice its own desktop window (pywebview)."""
    import importlib.util
    import subprocess
    if os.name != "nt" or importlib.util.find_spec("webview"):
        return
    marker = os.path.join(HERE, "window_lib_attempt.txt")
    if os.path.exists(marker) and time.time() - os.path.getmtime(marker) < 6 * 3600:
        return
    with open(marker, "w") as f:
        f.write(dt.datetime.now().isoformat())
    py = sys.executable
    if py.lower().endswith("pythonw.exe") and os.path.exists(py[:-11] + "python.exe"):
        py = py[:-11] + "python.exe"
    try:
        r = subprocess.run([py, "-m", "pip", "install", "--disable-pip-version-check", "--quiet", "pywebview"],
                           capture_output=True, text=True, timeout=900, creationflags=0x08000000)
        applog("SETUP", "OK" if r.returncode == 0 else "FAIL", f"pywebview install rc={r.returncode} {(r.stderr or r.stdout)[-600:]}")
    except Exception as e:
        applog("SETUP", "FAIL", f"pywebview install: {e}")


def background_watch():
    """Auto-restart when bridge.py changes, and run read-only test jobs dropped in jobs/."""
    me = os.path.abspath(__file__)
    start_mtime = os.path.getmtime(me)
    jobs = os.path.join(HERE, "jobs")
    os.makedirs(jobs, exist_ok=True)
    while True:
        time.sleep(3)
        try:
            if os.path.getmtime(me) != start_mtime:
                time.sleep(1)
                import subprocess
                flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                subprocess.Popen([sys.executable, me], cwd=HERE, creationflags=flags, close_fds=True)
                os._exit(0)
            for fn in sorted(os.listdir(jobs)):
                if not fn.endswith(".job.json"):
                    continue
                src = os.path.join(jobs, fn)
                try:
                    with open(src, encoding="utf-8") as f:
                        job = json.load(f)
                    fn_ = SAFE_JOBS.get(job.get("action"))
                    out = fn_(job.get("args", {})) if fn_ else {"error": "unknown action"}
                except Exception as e:
                    out = {"error": f"{type(e).__name__}: {e}"}
                with open(src.replace(".job.json", ".out.json"), "w", encoding="utf-8") as f:
                    json.dump(out, f, ensure_ascii=False, indent=1)
                os.remove(src)
        except Exception:
            pass


def main():
    if CFG["token"] in ("", "CHANGE_ME"):
        print("Set a token in config.json first.")
        sys.exit(1)
    srv = None
    for _ in range(20):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", int(CFG["port"])), Handler)
            break
        except OSError:
            time.sleep(1)
    if srv is None:
        sys.exit(1)
    threading.Thread(target=background_watch, daemon=True).start()
    threading.Thread(target=ensure_window_lib, daemon=True).start()
    threading.Thread(target=update_loop, daemon=True).start()
    threading.Thread(target=cloud_register, daemon=True).start()
    print(f"Tally Voice Bridge on http://127.0.0.1:{CFG['port']}  ->  Tally at {CFG['tally_url']}")
    print("Leave this window open. App: http://127.0.0.1:%s/" % CFG['port'])
    srv.serve_forever()


if __name__ == "__main__":
    main()
