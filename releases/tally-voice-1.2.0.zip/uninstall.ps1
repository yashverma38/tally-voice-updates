﻿# Tally Voice uninstaller (from Apps & features). Bills/receipts logs and settings are kept unless you choose to delete them.
$ErrorActionPreference = 'Continue'
$Target = $PSScriptRoot
Write-Host "Uninstalling Tally Voice from $Target" -ForegroundColor Yellow
Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -and ($_.CommandLine -like '*bridge.py*' -or $_.CommandLine -like '*app_window.py*') } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 600
foreach ($d in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path $d 'Tally Voice.lnk')
}
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TallyVoice'
$data = @('config.json','receipts_log.jsonl','usage.jsonl','printed')
$ans = Read-Host "Also delete this shop's settings, logs and saved prints? (y/N)"
Get-ChildItem -LiteralPath $Target -Force | Where-Object { ($ans -eq 'y') -or ($data -notcontains $_.Name) } |
  Where-Object { $_.Name -ne 'uninstall.ps1' } | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Tally Voice removed." -ForegroundColor Green
if ($ans -ne 'y') { Write-Host "Kept: settings, logs and saved prints in $Target" -ForegroundColor Gray }
Start-Sleep -Seconds 3
Remove-Item -Force -ErrorAction SilentlyContinue $PSCommandPath
