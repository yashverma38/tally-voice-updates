﻿# Tally Voice installer (run by TallyVoiceSetup.exe). No admin rights needed.
param(
  [string]$Source = $PSScriptRoot,
  [string]$Target = "$env:LOCALAPPDATA\TallyVoice",
  [switch]$NoLaunch
)
$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'Tally Voice Setup'
function Step($t) { Write-Host ""; Write-Host "==> $t" -ForegroundColor Yellow }
function Ok($t)   { Write-Host "    $t" -ForegroundColor Green }
function Note($t) { Write-Host "    $t" -ForegroundColor Gray }

try {
  $version = (Get-Content -Raw (Join-Path $Source 'VERSION')).Trim()
  Write-Host "Tally Voice $version  -  Verma Jewellers / Letsbloc" -ForegroundColor Cyan

  # 1. stop a running copy so files can be replaced
  Step "Closing Tally Voice if it is open"
  Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -and ($_.CommandLine -like '*bridge.py*' -or $_.CommandLine -like '*app_window.py*') -and $_.CommandLine -like "*$Target*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  Start-Sleep -Milliseconds 600

  # 2. copy program files (never overwrite this shop's config or data)
  Step "Copying files to $Target"
  New-Item -ItemType Directory -Force -Path $Target | Out-Null
  $keep = @('config.json','receipts_log.jsonl','usage.jsonl','app.log')
  Get-ChildItem -LiteralPath $Source -Recurse -File | ForEach-Object {
    $rel = $_.FullName.Substring($Source.TrimEnd('\').Length + 1)
    if ($keep -contains $rel) { return }
    $dst = Join-Path $Target $rel
    New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $dst -Force
  }
  Ok "Files copied"

  # 3. first-time settings (random private token for this PC)
  $cfg = Join-Path $Target 'config.json'
  if (-not (Test-Path $cfg)) {
    $c = Get-Content -Raw -Encoding UTF8 (Join-Path $Target 'config.example.json') | ConvertFrom-Json
    $c.token = -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 32 | ForEach-Object { [char]$_ })
    [IO.File]::WriteAllText($cfg, ($c | ConvertTo-Json -Depth 6), (New-Object Text.UTF8Encoding $false))
    Ok "Settings file created"
  } else { Ok "Existing settings kept" }

  # 4. Python (per-user, quiet) - only if not already there
  Step "Checking Python"
  $py = $null
  foreach ($v in 'Python312','Python313','Python311') {
    $p = "$env:LOCALAPPDATA\Programs\Python\$v\pythonw.exe"
    if (Test-Path $p) { $py = $p; break }
  }
  if (-not $py) {
    Note "Downloading Python 3.12 (about 25 MB)..."
    $inst = Join-Path $env:TEMP 'python-3.12.10-amd64.exe'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile $inst
    Note "Installing Python (2-3 minutes)..."
    Start-Process -Wait -FilePath $inst -ArgumentList '/quiet','InstallAllUsers=0','PrependPath=0','Include_launcher=0','Include_test=0','Include_doc=0','Shortcuts=0'
    $py = "$env:LOCALAPPDATA\Programs\Python\Python312\pythonw.exe"
    if (-not (Test-Path $py)) { throw "Python did not install. Install Python 3.12 from python.org and run setup again." }
  }
  Ok "Python: $py"

  # 5. desktop-window library
  Step "Installing the window library"
  $pyexe = $py -replace 'pythonw\.exe$','python.exe'
  & $pyexe -m pip install --disable-pip-version-check --quiet --upgrade pywebview 2>&1 | Out-Null
  if ($LASTEXITCODE -ne 0) { Note "Could not install it now - the app will use an Edge window and retry later." } else { Ok "Done" }

  # 6. shortcuts
  Step "Creating shortcuts"
  $exe = Join-Path $Target 'Tally Voice.exe'
  $ws = New-Object -ComObject WScript.Shell
  foreach ($lnk in @([Environment]::GetFolderPath('Desktop'), (Join-Path ([Environment]::GetFolderPath('Programs')) ''))) {
    $s = $ws.CreateShortcut((Join-Path $lnk 'Tally Voice.lnk'))
    $s.TargetPath = $exe; $s.WorkingDirectory = $Target; $s.IconLocation = "$exe,0"; $s.Description = 'Tally Voice - bills and receipts into TallyPrime'
    $s.Save()
  }
  Ok "Desktop and Start menu"

  # 7. Apps & features entry (uninstall)
  $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TallyVoice'
  New-Item -Force -Path $key | Out-Null
  Set-ItemProperty $key DisplayName 'Tally Voice'
  Set-ItemProperty $key DisplayVersion $version
  Set-ItemProperty $key Publisher 'Letsbloc Apps Private Limited'
  Set-ItemProperty $key InstallLocation $Target
  Set-ItemProperty $key DisplayIcon "$exe,0"
  Set-ItemProperty $key UninstallString "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$Target\uninstall.ps1`""
  Set-ItemProperty $key NoModify 1 -Type DWord
  Set-ItemProperty $key NoRepair 1 -Type DWord

  # 8. is Tally listening?
  Step "Checking TallyPrime connection (port 9000)"
  try {
    Invoke-WebRequest -UseBasicParsing -TimeoutSec 4 -Method Post -Body '<ENVELOPE><HEADER><TALLYREQUEST>Export Data</TALLYREQUEST></HEADER><BODY><EXPORTDATA><REQUESTDESC><REPORTNAME>List of Companies</REPORTNAME></REQUESTDESC></EXPORTDATA></BODY></ENVELOPE>' 'http://localhost:9000' | Out-Null
    Ok "TallyPrime is connected"
  } catch {
    Note "TallyPrime is not answering on port 9000."
    Note "In TallyPrime: F1 (Help) > Settings > Connectivity > Client/Server configuration:"
    Note "  TallyPrime acts as = Both,  Port = 9000. Then restart TallyPrime."
  }

  Write-Host ""
  Write-Host "Tally Voice $version is installed." -ForegroundColor Cyan
  Write-Host "Open it from the 'Tally Voice' icon on the desktop. Add API keys in the app under Settings." -ForegroundColor Cyan
  if (-not $NoLaunch) { Start-Process -FilePath $exe -WorkingDirectory $Target }
  Start-Sleep -Seconds 4
  exit 0
} catch {
  Write-Host ""
  Write-Host "Setup failed: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host "Press Enter to close." ; [void](Read-Host)
  exit 1
}
