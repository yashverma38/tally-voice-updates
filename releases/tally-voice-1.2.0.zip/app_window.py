"""Tally Voice desktop window.

Opens the app in its own Windows window (Microsoft WebView2, the engine built into Windows 11)
instead of a browser: own title, own icon, own taskbar button, no tabs or address bar.
If the window library is not installed yet, it falls back to the Edge app window.
"""
import ctypes
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
# started with pythonw.exe there is no console: give print/logging somewhere to write, or the window library can crash
if sys.stdout is None or sys.stderr is None:
    _out = open(os.path.join(HERE, "window_err.log"), "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stdout or _out
    sys.stderr = sys.stderr or _out
URL = "http://127.0.0.1:8765/"
TITLE = "Verma Jewellers · Tally"
ICON = os.path.join(HERE, "tally_voice.ico")


def log(msg):
    try:
        import datetime as dt
        with open(os.path.join(HERE, "app.log"), "a", encoding="utf-8") as f:
            f.write(f"{dt.datetime.now():%Y-%m-%d %H:%M:%S} [WINDOW] {msg}\n")
    except Exception:
        pass


def edge_fallback():
    args = [f"--app={URL}", "--window-size=1360,860", "--autoplay-policy=no-user-gesture-required"]
    for exe in ("msedge", "chrome"):
        try:
            subprocess.Popen(["cmd", "/c", "start", "", exe, *args], creationflags=0x08000000)
            return
        except Exception:
            continue
    os.startfile(URL)


def bring_existing_to_front():
    user32 = ctypes.windll.user32
    hwnd = user32.FindWindowW(None, TITLE)
    if hwnd:
        user32.ShowWindow(hwnd, 9)          # SW_RESTORE
        user32.SetForegroundWindow(hwnd)
        return True
    return False


def main():
    # one window only: a second double-click just brings the open one forward
    mutex = ctypes.windll.kernel32.CreateMutexW(None, False, "VermaJewellers.TallyVoice.Window")
    if ctypes.windll.kernel32.GetLastError() == 183:      # ERROR_ALREADY_EXISTS
        bring_existing_to_front()
        return
    # own taskbar identity (otherwise Windows groups it under Python)
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("VermaJewellers.TallyVoice")
    except Exception:
        pass
    try:
        import webview
    except Exception as e:
        log(f"window library not available ({e}); using Edge app window")
        edge_fallback()
        return

    # local app on this PC only: let the page use the microphone without a prompt, and play sounds
    os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = "--use-fake-ui-for-media-stream --autoplay-policy=no-user-gesture-required"
    window = webview.create_window(TITLE, URL, width=1380, height=880, min_size=(1100, 680), text_select=True)

    try:
        webview.start(gui="edgechromium", private_mode=False,
                      storage_path=os.path.join(HERE, "window_data"), icon=ICON if os.path.exists(ICON) else None)
    except Exception as e:
        log(f"window failed ({e}); using Edge app window")
        edge_fallback()
    finally:
        if mutex:
            ctypes.windll.kernel32.CloseHandle(mutex)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        import traceback
        log(f"crashed: {e}\n{traceback.format_exc()}")
        edge_fallback()
